/* =====================================================================
   Script maestro: crea las 5 bases de datos bancarias de una sola vez.
   Requiere MODO SQLCMD en SSMS (menú Consulta > Modo SQLCMD)
   o ejecutarlo con:  sqlcmd -S localhost -E -i "00_Ejecutar_Todo.sql"
   Cambie la ruta de la carpeta antes de ejecutar.
   ===================================================================== */
:setvar Carpeta "C:\BancosSQL"

:r $(Carpeta)\01_BancaTarjetasCredito.sql
:r $(Carpeta)\02_BancaCuentasDebito.sql
:r $(Carpeta)\03_BancaTokenizacion.sql
:r $(Carpeta)\04_BancaLeasing.sql
:r $(Carpeta)\05_BancaPrestamos.sql

PRINT N'=== Las 5 bases de datos fueron creadas ===';
GO
