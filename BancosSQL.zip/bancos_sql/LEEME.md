# Bases de datos bancarias de prueba – SQL Server

Datos 100 % ficticios (contexto El Salvador, moneda USD, fecha de referencia 14/10/2026).
Los números de tarjeta y token siempre van enmascarados (BIN + ****** + últimos 4).

| Archivo | Base de datos | Tablas principales | Registros aprox. |
|---|---|---|---|
| 01_BancaTarjetasCredito.sql | BancaTarjetasCredito | Clientes, ProductosTarjeta, Comercios, TarjetasCredito, TransaccionesTC, EstadosCuentaTC, PagosTC | ~169 000 |
| 02_BancaCuentasDebito.sql | BancaCuentasDebito | Clientes, Agencias, CuentasDeposito, TarjetasDebito, CajerosATM, MovimientosCuenta, BloqueosTarjeta | ~93 000 |
| 03_BancaTokenizacion.sql | BancaTokenizacion | Clientes, ProveedoresToken (VTS/MDES), Wallets, TarjetasOrigen, Dispositivos, Tokens, EventosCicloVidaToken, TransaccionesTokenizadas | ~90 000 |
| 04_BancaLeasing.sql | BancaLeasing | Arrendatarios, ProveedoresActivo, Activos, ContratosLeasing, CuotasLeasing, SegurosActivo | ~82 000 |
| 05_BancaPrestamos.sql | BancaPrestamos | Clientes, EjecutivosNegocio, ProductosPrestamo, SolicitudesCredito, Prestamos, CuotasPrestamo, PagosPrestamo, Garantias, GestionesCobro | ~152 000 |

## Cómo cargarlas

**Opción 1 – sqlcmd (recomendada, los archivos pesan 9–18 MB):**
```
sqlcmd -S localhost -E -i "01_BancaTarjetasCredito.sql"
```
(Use `-U usuario -P clave` en lugar de `-E` si no usa autenticación de Windows.)

**Opción 2 – SSMS:** abra el archivo y presione F5. Cada script borra y vuelve a crear su base de datos.

**Opción 3 – todas a la vez:** copie la carpeta a `C:\BancosSQL`, abra `00_Ejecutar_Todo.sql`, active *Consulta > Modo SQLCMD* y ejecute.

## Detalles útiles

- La tabla **Clientes** es idéntica en las bases 01, 02, 03 y 05 (mismo ClienteID y DUI), así que puede cruzarlas, por ejemplo:
  ```sql
  SELECT c.DUI, COUNT(DISTINCT tc.TarjetaID) AS TarjetasCredito, COUNT(DISTINCT p.PrestamoID) AS Prestamos
  FROM BancaTarjetasCredito.dbo.Clientes c
  LEFT JOIN BancaTarjetasCredito.dbo.TarjetasCredito tc ON tc.ClienteID = c.ClienteID
  LEFT JOIN BancaPrestamos.dbo.Prestamos p ON p.ClienteID = c.ClienteID
  GROUP BY c.DUI;
  ```
- Los datos son coherentes entre tablas: los estados de cuenta suman las transacciones aprobadas del periodo, los saldos de cuenta cuadran con `SaldoPosterior`, las cuotas siguen amortización francesa y la mora define la categoría de riesgo (A1–E, NCB-022).
- Incluyen casos para pruebas: transacciones rechazadas con motivo, tarjetas bloqueadas/robadas, tokens suspendidos y eliminados, contratos y préstamos en mora, cancelaciones anticipadas y gestiones de cobro.
- Cada base trae índices y una vista de resumen (`vw_...`).
