# -*- coding: utf-8 -*-
"""Generador de 5 bases de datos bancarias (SQL Server) con datos ficticios."""
import random, math, os, datetime as dt, hashlib, unicodedata

HOY = dt.date(2026, 10, 14)
OUT = "bancos_sql"
os.makedirs(OUT, exist_ok=True)
D = dt.timedelta

# ---------------------------------------------------------------- utilidades
class Raw(str):
    pass

def q(v):
    if v is None: return "NULL"
    if isinstance(v, Raw): return str(v)
    if isinstance(v, bool): return "1" if v else "0"
    if isinstance(v, int): return str(v)
    if isinstance(v, float): return f"{v:.2f}"
    if isinstance(v, dt.datetime): return "'" + v.strftime("%Y-%m-%dT%H:%M:%S") + "'"
    if isinstance(v, dt.date): return "'" + v.isoformat() + "'"
    return "N'" + str(v).replace("'", "''") + "'"

def r2(x): return round(float(x), 2)

def add_months(d, m):
    y, mo = divmod(d.month - 1 + m, 12)
    y += d.year; mo += 1
    dim = [31, 29 if (y % 4 == 0 and (y % 100 != 0 or y % 400 == 0)) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][mo - 1]
    return dt.date(y, mo, min(d.day, dim))

def months_between(a, b):
    return (b.year - a.year) * 12 + (b.month - a.month) - (1 if b.day < a.day else 0)

def unaccent(s):
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")

def rand_dt(rnd, d1, d2):
    days = max((d2 - d1).days, 0)
    d = d1 + D(days=rnd.randint(0, days))
    h = rnd.choices(range(24), weights=[1,1,1,1,1,2,4,6,8,9,9,10,11,10,9,9,9,9,10,10,8,6,4,2])[0]
    return dt.datetime(d.year, d.month, d.day, h, rnd.randint(0, 59), rnd.randint(0, 59))

def cuota_francesa(P, tasa_anual, n):
    r = tasa_anual / 1200
    return P / n if r == 0 else P * r / (1 - (1 + r) ** -n)

def header(f, db, titulo, tablas):
    f.write(f"""/* =====================================================================
   Base de datos : {db}
   Contenido     : {titulo}
   Tablas        : {tablas}
   Motor         : Microsoft SQL Server 2016 o superior
   Generado      : {HOY.isoformat()}  (datos 100% ficticios, PAN siempre enmascarado)
   Ejecución     : SSMS (F5) o  sqlcmd -S servidor -E -i "archivo.sql"
   ===================================================================== */
USE master;
GO
IF DB_ID(N'{db}') IS NOT NULL
BEGIN
    ALTER DATABASE [{db}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE [{db}];
END
GO
CREATE DATABASE [{db}];
GO
USE [{db}];
GO
SET NOCOUNT ON;
GO

""")

def inserts(f, table, cols, rows, identity=True):
    f.write(f"PRINT N'Cargando dbo.{table} ({len(rows):,} registros)...';\n")
    if identity: f.write(f"SET IDENTITY_INSERT dbo.{table} ON;\n")
    for i in range(0, len(rows), 1000):
        f.write(f"INSERT INTO dbo.{table} ({', '.join(cols)}) VALUES\n")
        f.write(",\n".join("(" + ", ".join(q(v) for v in r) + ")" for r in rows[i:i + 1000]))
        f.write(";\n")
    if identity: f.write(f"SET IDENTITY_INSERT dbo.{table} OFF;\n")
    f.write("GO\n\n")

def footer(f, db, tablas):
    f.write(f"PRINT N'--- Resumen {db} ---';\n")
    parts = [f"SELECT N'{t}' AS Tabla, COUNT(*) AS Registros FROM dbo.{t}" for t in tablas]
    f.write("\nUNION ALL ".join(parts) + ";\nGO\n")

STATS = {}

# ---------------------------------------------------------------- catálogos
NOM_M = ["José","Juan","Carlos","Luis","Mario","Jorge","Francisco","Miguel","Roberto","Ricardo","Óscar","Manuel","David","Daniel","Fernando","Rafael","Eduardo","Alejandro","Javier","Ernesto","Rodrigo","Héctor","Raúl","Andrés","Diego","Kevin","Bryan","Josué","Samuel","Walter","Nelson","René","Edwin","Mauricio","Gerardo","Alberto","Julio","César","Emilio","Marvin"]
NOM_F = ["María","Ana","Rosa","Carmen","Gloria","Patricia","Sandra","Claudia","Karla","Andrea","Gabriela","Daniela","Sofía","Fátima","Jennifer","Alejandra","Verónica","Silvia","Marta","Lucía","Elena","Beatriz","Reina","Xiomara","Yesenia","Wendy","Paola","Mónica","Lorena","Cecilia","Brenda","Diana","Evelyn","Irma","Julia","Rocío","Tatiana","Valeria","Ximena","Zulma"]
APE = ["Hernández","García","Martínez","López","Rodríguez","González","Pérez","Ramírez","Flores","Rivera","Cruz","Sánchez","Reyes","Morales","Ortiz","Torres","Díaz","Castillo","Romero","Gómez","Mejía","Aguilar","Alvarado","Portillo","Rivas","Guzmán","Menjívar","Orellana","Escobar","Ayala","Chávez","Vásquez","Bonilla","Quintanilla","Argueta","Campos","Velásquez","Navarro","Molina","Fuentes","Cáceres","Zelaya","Henríquez","Arévalo","Durán","Lemus","Pineda","Serrano","Villalta","Mendoza"]
DEPTOS = {
    "San Salvador": ["San Salvador","Mejicanos","Soyapango","Apopa","Ilopango","San Marcos","Ayutuxtepeque","Cuscatancingo","Tonacatepeque"],
    "La Libertad": ["Santa Tecla","Antiguo Cuscatlán","La Libertad","Colón","Quezaltepeque","Zaragoza","Nuevo Cuscatlán"],
    "Santa Ana": ["Santa Ana","Chalchuapa","Metapán","El Congo","Coatepeque"],
    "San Miguel": ["San Miguel","Chinameca","Ciudad Barrios","Moncagua"],
    "Sonsonate": ["Sonsonate","Acajutla","Izalco","Nahuizalco","Armenia"],
    "Ahuachapán": ["Ahuachapán","Atiquizaya","Apaneca","Tacuba"],
    "La Paz": ["Zacatecoluca","Olocuilta","San Pedro Masahuat","El Rosario"],
    "Usulután": ["Usulután","Jiquilisco","Santiago de María","Berlín"],
    "La Unión": ["La Unión","Santa Rosa de Lima","Conchagua"],
    "Cuscatlán": ["Cojutepeque","Suchitoto","San Rafael Cedros"],
    "Chalatenango": ["Chalatenango","Nueva Concepción","La Palma"],
    "Cabañas": ["Sensuntepeque","Ilobasco"],
    "San Vicente": ["San Vicente","Tecoluca","Apastepeque"],
    "Morazán": ["San Francisco Gotera","Perquín","Jocoro"],
}
DEPTO_PESOS = [30,18,9,8,7,4,4,4,3,3,3,2,3,2]
DOMINIOS = ["gmail.com","hotmail.com","outlook.com","yahoo.com","icloud.com","correo.sv"]

def gen_clientes(n=3000):
    rnd = random.Random(42)
    rows, duis = [], set()
    for i in range(1, n + 1):
        g = rnd.choice("MF")
        noms = rnd.sample(NOM_M if g == "M" else NOM_F, 2)
        a1, a2 = rnd.sample(APE, 2)
        nac = HOY - D(days=rnd.randint(19 * 365, 75 * 365))
        while True:
            dui = f"{rnd.randint(1000000, 99999999):08d}-{rnd.randint(0, 9)}"
            if dui not in duis: duis.add(dui); break
        email = unaccent(f"{noms[0]}.{a1}{rnd.randint(1, 999)}").lower() + "@" + rnd.choice(DOMINIOS)
        tel = f"{rnd.choice('677')}{rnd.randint(0, 999):03d}-{rnd.randint(0, 9999):04d}"
        dep = rnd.choices(list(DEPTOS), weights=DEPTO_PESOS)[0]
        mun = rnd.choice(DEPTOS[dep])
        ing = r2(min(max(rnd.lognormvariate(6.95, 0.65), 365), 18000))
        seg = "Masivo" if ing < 700 else "Emergente" if ing < 1500 else "Preferente" if ing < 4000 else "Premium"
        min_alta = nac + D(days=18 * 365 + 5)
        alta = max(min_alta, HOY - D(days=rnd.randint(30, 15 * 365)))
        rows.append([i, dui, " ".join(noms), f"{a1} {a2}", nac, g, email, tel, dep, mun, ing, seg, alta])
    return rows

CLIENTES = gen_clientes()
CLI_COLS = ["ClienteID","DUI","Nombres","Apellidos","FechaNacimiento","Genero","Email","Telefono","Departamento","Municipio","IngresoMensual","Segmento","FechaAlta"]
CLI_DDL = """CREATE TABLE dbo.Clientes (
    ClienteID        INT IDENTITY(1,1) CONSTRAINT PK_Clientes PRIMARY KEY,
    DUI              CHAR(10)       NOT NULL CONSTRAINT UQ_Clientes_DUI UNIQUE,
    Nombres          NVARCHAR(60)   NOT NULL,
    Apellidos        NVARCHAR(60)   NOT NULL,
    FechaNacimiento  DATE           NOT NULL,
    Genero           CHAR(1)        NOT NULL CONSTRAINT CK_Clientes_Genero CHECK (Genero IN ('M','F')),
    Email            NVARCHAR(120)  NULL,
    Telefono         VARCHAR(15)    NULL,
    Departamento     NVARCHAR(40)   NOT NULL,
    Municipio        NVARCHAR(60)   NOT NULL,
    IngresoMensual   DECIMAL(12,2)  NOT NULL,
    Segmento         NVARCHAR(20)   NOT NULL,
    FechaAlta        DATE           NOT NULL
);
GO
"""

MCC = [  # mcc, categoria, nombres base, monto min, monto max, peso
    (5411, "Supermercados", ["Supermercado La Económica","Súper Del Pueblo","Mercado Fresco","Hiper Familiar","Súper Ahorro"], 8, 180, 22),
    (5812, "Restaurantes", ["Restaurante El Comal","Pupusería La Ceiba","Asados Don Chepe","Café Volcán","Marisquería El Puerto"], 6, 90, 14),
    (5814, "Comida rápida", ["Pollo Campero Express","Burger Planet","Pizza Nostra","Taco Loco","Sub Station"], 4, 35, 14),
    (5541, "Gasolineras", ["Gasolinera Central","Estación Rápida","Combustibles del Sur","Servicentro Norte"], 10, 75, 10),
    (5912, "Farmacias", ["Farmacia Salud Total","Farmacia La Esperanza","Droguería Vida","Farmacia Popular"], 3, 90, 7),
    (5311, "Tiendas departamentales", ["Almacenes Prisma","Tienda Siman Plaza","Departamental Metro","Galerías Hogar"], 15, 400, 5),
    (5732, "Electrónica", ["ElectroMundo","Tecno Plaza","Digital Center","Curacao Hogar"], 25, 1500, 3),
    (4814, "Telecomunicaciones", ["Telefonía Móvil SV","Cable e Internet Total","NetHogar"], 10, 80, 4),
    (4900, "Servicios públicos", ["Distribuidora Eléctrica","Agua Potable Municipal"], 12, 120, 4),
    (5651, "Ropa y calzado", ["Moda Joven","Calzado Estrella","Boutique Elegance","Outlet Familiar"], 10, 250, 5),
    (8062, "Hospitales y clínicas", ["Hospital Metropolitano","Clínica Médica Integral","Laboratorio Clínico Central"], 20, 900, 2),
    (5999, "Comercio electrónico", ["Tienda Online Global","Marketplace Express","App Store Digital","Plataforma Streaming"], 3, 300, 6),
    (7011, "Hoteles", ["Hotel Pacífico","Hotel Montaña Verde","Resort Playa Azul"], 60, 600, 1),
    (4511, "Aerolíneas", ["Aerolínea Centroamericana","Air Pacífico","Vuela Ya"], 120, 1200, 1),
    (7832, "Cines y entretenimiento", ["Cinema Plaza","Cines Metro","Bolera Galáctica"], 5, 45, 2),
    (5200, "Ferreterías", ["Ferretería El Tornillo","Construmarket","Ferre Hogar"], 5, 350, 2),
    (4111, "Transporte", ["Transporte Urbano App","Taxi Seguro","Movilidad Express"], 2, 25, 3),
]
PAISES_ECOM = ["US","US","US","SV","MX","ES"]

def gen_comercios(rnd, n=400):
    rows = []
    for i in range(1, n + 1):
        m = rnd.choices(MCC, weights=[x[5] for x in MCC])[0]
        dep = rnd.choices(list(DEPTOS), weights=DEPTO_PESOS)[0]
        ciudad = rnd.choice(DEPTOS[dep])
        pais = rnd.choice(PAISES_ECOM) if m[0] == 5999 else ("US" if rnd.random() < 0.04 else "SV")
        if m[0] in (7011, 4511) and rnd.random() < 0.5: pais = rnd.choice(["US","GT","MX","CR","PA"])
        nombre = f"{rnd.choice(m[2])} {ciudad if pais == 'SV' else pais} #{rnd.randint(1, 40)}"
        rows.append([i, nombre, m[0], m[1], ciudad if pais == "SV" else None, pais])
    return rows

# ============================================================ 1. TARJETAS DE CRÉDITO
def db_tarjetas_credito():
    rnd = random.Random(101)
    db = "BancaTarjetasCredito"
    prods = [  # id, nombre, marca, categoria, limmin, limmax, tasa, cuota anual, bin, programa
        [1, "Visa Clásica", "Visa", "Clásica", 300, 2000, 34.00, 25.00, "400012", "Puntos"],
        [2, "Visa Oro", "Visa", "Oro", 1500, 6000, 32.50, 45.00, "400034", "Puntos"],
        [3, "Visa Platinum", "Visa", "Platinum", 5000, 15000, 30.00, 95.00, "400056", "Millas"],
        [4, "Visa Infinite", "Visa", "Infinite", 15000, 50000, 27.50, 250.00, "400078", "Millas"],
        [5, "Mastercard Standard", "Mastercard", "Clásica", 300, 2000, 34.00, 25.00, "510011", "Cashback"],
        [6, "Mastercard Gold", "Mastercard", "Oro", 1500, 6000, 32.50, 45.00, "510022", "Cashback"],
        [7, "Mastercard Black", "Mastercard", "Black", 15000, 50000, 27.00, 275.00, "510033", "Millas"],
        [8, "Visa Cashback Digital", "Visa", "Oro", 1000, 5000, 33.00, 0.00, "400090", "Cashback"],
        [9, "Mastercard Empresarial", "Mastercard", "Corporativa", 2000, 25000, 29.00, 120.00, "510044", "Ninguno"],
        [10, "Visa Joven", "Visa", "Clásica", 200, 1000, 35.00, 0.00, "400011", "Puntos"],
    ]
    by_seg = {"Masivo": [1, 5, 10, 8], "Emergente": [2, 6, 8, 1], "Preferente": [3, 2, 6, 9], "Premium": [4, 7, 3, 9]}
    comercios = gen_comercios(rnd)
    com_by_mcc = {}
    for c in comercios: com_by_mcc.setdefault(c[2], []).append(c)
    mcc_info = {m[0]: m for m in MCC}

    tarjetas, txs, ecs, pagos = [], [], [], []
    tid = 0
    for cli in CLIENTES:
        if rnd.random() > 0.78: continue
        ncards = rnd.choices([1, 2, 3], weights=[70, 24, 6])[0]
        for k in range(ncards):
            tid += 1
            p = prods[rnd.choice(by_seg[cli[11]]) - 1]
            lim = min(p[5], max(p[4], round(cli[10] * rnd.uniform(1.0, 3.5) / 50) * 50))
            emis = max(cli[12], HOY - D(days=rnd.randint(20, 5 * 365)))
            venc = add_months(emis, 60)
            estado = rnd.choices(["Activa","Bloqueada","Cancelada","Robada/Extraviada","Inactiva"], weights=[82,5,8,2,3])[0]
            corte = rnd.choice([5, 10, 15, 20, 25])
            last4 = f"{rnd.randint(0, 9999):04d}"
            adicional = k > 0 and rnd.random() < 0.35
            titular = tid - 1 if adicional else None
            comport = rnd.choices(["Totalero","Revolvente","Moroso"], weights=[40, 50, 10])[0]
            tarjetas.append([tid, cli[0], p[0], p[8] + "******" + last4, p[8], last4, emis, venc, float(lim), 0.0,
                             estado, corte, None, adicional, titular, comport, None])
            if estado == "Robada/Extraviada" and comport != "Moroso": pass
            # ---- simulación mensual
            cortes = []
            c = dt.date(HOY.year, HOY.month, corte)
            if c > HOY: c = add_months(c, -1)
            for m in range(11, -1, -1):
                cc = add_months(c, -m)
                if cc > emis: cortes.append(cc)
            fin_act = HOY
            if estado == "Cancelada": fin_act = HOY - D(days=rnd.randint(60, 200))
            elif estado in ("Bloqueada", "Robada/Extraviada"): fin_act = HOY - D(days=rnd.randint(5, 60))
            elif estado == "Inactiva": fin_act = HOY - D(days=rnd.randint(200, 360))
            saldo = r2(lim * rnd.uniform(0, 0.25)) if emis < HOY - D(days=400) else 0.0
            prev = None
            mora = 0
            factor = {"Clásica": 1, "Oro": 1.4, "Platinum": 2.2, "Infinite": 3.5, "Black": 3.5, "Corporativa": 2.5}[p[3]]
            periodos = [(add_months(cc, -1) + D(days=1), cc) for cc in cortes] + [(c + D(days=1), HOY)]
            for idx, (ini, fin) in enumerate(periodos):
                ini = max(ini, emis)
                es_abierto = idx == len(periodos) - 1
                compras = 0.0
                n = rnd.choices([0, 1, 2, 3, 4, 5, 6], weights=[10, 15, 20, 20, 15, 12, 8])[0] if ini <= fin_act else 0
                for _ in range(n):
                    f = rand_dt(rnd, ini, min(fin, fin_act))
                    tipo = rnd.choices(["Compra","Avance de efectivo","Devolución"], weights=[94, 4, 2])[0]
                    if tipo == "Avance de efectivo":
                        com, canal = None, "ATM"
                        monto = r2(rnd.choice([20, 40, 60, 100, 150, 200, 300]))
                    else:
                        mcc = rnd.choices(MCC, weights=[x[5] for x in MCC])[0][0]
                        com = rnd.choice(com_by_mcc.get(mcc) or comercios)
                        mi = mcc_info[com[2]]
                        monto = r2(rnd.uniform(mi[3], mi[4]) * (factor if rnd.random() < 0.5 else 1))
                        canal = "E-commerce" if com[2] == 5999 or rnd.random() < 0.08 else rnd.choices(["POS Chip","Contactless","POS Banda"], weights=[45, 50, 5])[0]
                        com = com[0]
                    cuotas = rnd.choice([3, 6, 12]) if tipo == "Compra" and monto > 300 and rnd.random() < 0.3 else 1
                    disponible = lim - (saldo + compras)
                    motivo = None
                    if tipo != "Devolución" and rnd.random() < 0.04:
                        motivo = rnd.choice(["CVV incorrecto","Sospecha de fraude","PIN incorrecto","Comercio no permitido","Tarjeta vencida en comercio"])
                    elif tipo != "Devolución" and monto > disponible:
                        motivo = "Excede límite de crédito"
                    if mora >= 60 and tipo != "Devolución": motivo = "Cuenta en mora"
                    est = "Rechazada" if motivo else "Aprobada"
                    if est == "Aprobada":
                        compras += -monto if tipo == "Devolución" else monto
                    auth = f"{rnd.randint(0, 999999):06d}" if est == "Aprobada" else None
                    txs.append([f, tid, com, tipo, monto, "USD", canal, cuotas, auth, est, motivo])
                if es_abierto:
                    saldo = r2(saldo + compras)
                    break
                # pago del estado anterior
                pago = 0.0
                if prev:
                    sc, pm, flim = prev
                    if sc > 0:
                        if comport == "Totalero": pago = sc
                        elif comport == "Revolvente": pago = r2(rnd.uniform(pm, max(pm, sc * 0.5)))
                        else: pago = 0.0 if rnd.random() < 0.55 else pm
                        if estado == "Cancelada" and fin > fin_act: pago = sc
                    if pago > 0:
                        fp = flim - D(days=rnd.randint(0, 12)) if comport != "Moroso" else flim + D(days=rnd.randint(-3, 15))
                        fp = min(max(fp, ini), HOY)
                        pagos.append([tid, fp, r2(pago), rnd.choices(["Banca en línea","App móvil","Agencia","Débito automático","Corresponsal"], weights=[30, 35, 15, 12, 8])[0]])
                        mora = 0 if pago >= pm - 0.01 else mora + 30
                    elif sc > 0:
                        mora += 30
                interes = 0.0
                if prev and prev[0] - pago > 0.01:
                    interes = r2((prev[0] - pago) * p[6] / 1200)
                cargo_anual = p[7] if fin.month == emis.month and p[7] > 0 else 0.0
                saldo_ant = saldo
                sc = r2(saldo_ant - pago + compras + interes + cargo_anual)
                pm = 0.0 if sc <= 0 else r2(min(sc, max(25.0, sc * 0.05)))
                flim = fin + D(days=20)
                ecs.append([tid, f"{fin.year}-{fin.month:02d}", fin, r2(saldo_ant), r2(compras), r2(pago), interes, cargo_anual, sc, pm, flim, mora])
                saldo = sc
                prev = (sc, pm, flim)
            t = tarjetas[-1]
            t[9] = r2(max(saldo, 0.0)) if estado != "Cancelada" else 0.0
            t[12] = r2(max(lim - t[9], 0.0))
            t[16] = mora

    txs.sort(key=lambda x: x[0])
    tx_rows = [[i + 1, x[1], x[2], x[0]] + x[3:] for i, x in enumerate(txs)]
    pagos.sort(key=lambda x: x[1])
    pago_rows = [[i + 1] + x for i, x in enumerate(pagos)]
    ec_rows = [[i + 1] + x for i, x in enumerate(ecs)]

    tablas = ["Clientes","ProductosTarjeta","Comercios","TarjetasCredito","TransaccionesTC","EstadosCuentaTC","PagosTC"]
    with open(f"{OUT}/01_BancaTarjetasCredito.sql", "w", encoding="utf-8-sig") as f:
        header(f, db, "Tarjetas de crédito: clientes, productos, plásticos, transacciones, estados de cuenta y pagos", ", ".join(tablas))
        f.write(CLI_DDL)
        f.write("""CREATE TABLE dbo.ProductosTarjeta (
    ProductoID        INT IDENTITY(1,1) CONSTRAINT PK_ProductosTarjeta PRIMARY KEY,
    Nombre            NVARCHAR(60)  NOT NULL,
    Marca             NVARCHAR(20)  NOT NULL,
    Categoria         NVARCHAR(20)  NOT NULL,
    LimiteMinimo      DECIMAL(12,2) NOT NULL,
    LimiteMaximo      DECIMAL(12,2) NOT NULL,
    TasaInteresAnual  DECIMAL(5,2)  NOT NULL,
    CuotaAnual        DECIMAL(10,2) NOT NULL,
    BIN               CHAR(6)       NOT NULL,
    ProgramaLealtad   NVARCHAR(20)  NOT NULL
);
GO
CREATE TABLE dbo.Comercios (
    ComercioID   INT IDENTITY(1,1) CONSTRAINT PK_Comercios PRIMARY KEY,
    Nombre       NVARCHAR(100) NOT NULL,
    MCC          SMALLINT      NOT NULL,
    CategoriaMCC NVARCHAR(40)  NOT NULL,
    Ciudad       NVARCHAR(60)  NULL,
    Pais         CHAR(2)       NOT NULL
);
GO
CREATE TABLE dbo.TarjetasCredito (
    TarjetaID          INT IDENTITY(1,1) CONSTRAINT PK_TarjetasCredito PRIMARY KEY,
    ClienteID          INT           NOT NULL CONSTRAINT FK_TC_Clientes REFERENCES dbo.Clientes(ClienteID),
    ProductoID         INT           NOT NULL CONSTRAINT FK_TC_Productos REFERENCES dbo.ProductosTarjeta(ProductoID),
    PANEnmascarado     CHAR(16)      NOT NULL,
    BIN                CHAR(6)       NOT NULL,
    Ultimos4           CHAR(4)       NOT NULL,
    FechaEmision       DATE          NOT NULL,
    FechaVencimiento   DATE          NOT NULL,
    LimiteCredito      DECIMAL(12,2) NOT NULL,
    SaldoActual        DECIMAL(12,2) NOT NULL,
    Estado             NVARCHAR(20)  NOT NULL,
    DiaCorte           TINYINT       NOT NULL,
    DisponibleCompras  DECIMAL(12,2) NULL,
    EsAdicional        BIT           NOT NULL,
    TarjetaTitularID   INT           NULL CONSTRAINT FK_TC_Titular REFERENCES dbo.TarjetasCredito(TarjetaID),
    PerfilPago         NVARCHAR(15)  NOT NULL,
    DiasMora           SMALLINT      NOT NULL DEFAULT 0
);
GO
CREATE TABLE dbo.TransaccionesTC (
    TransaccionID      BIGINT IDENTITY(1,1) CONSTRAINT PK_TransaccionesTC PRIMARY KEY,
    TarjetaID          INT           NOT NULL CONSTRAINT FK_TxTC_Tarjeta REFERENCES dbo.TarjetasCredito(TarjetaID),
    ComercioID         INT           NULL CONSTRAINT FK_TxTC_Comercio REFERENCES dbo.Comercios(ComercioID),
    FechaHora          DATETIME2(0)  NOT NULL,
    TipoTransaccion    NVARCHAR(25)  NOT NULL,
    Monto              DECIMAL(12,2) NOT NULL,
    Moneda             CHAR(3)       NOT NULL,
    Canal              NVARCHAR(20)  NOT NULL,
    NumeroCuotas       TINYINT       NOT NULL,
    CodigoAutorizacion CHAR(6)       NULL,
    Estado             NVARCHAR(12)  NOT NULL,
    MotivoRechazo      NVARCHAR(60)  NULL
);
GO
CREATE TABLE dbo.EstadosCuentaTC (
    EstadoCuentaID   INT IDENTITY(1,1) CONSTRAINT PK_EstadosCuentaTC PRIMARY KEY,
    TarjetaID        INT           NOT NULL CONSTRAINT FK_EC_Tarjeta REFERENCES dbo.TarjetasCredito(TarjetaID),
    Periodo          CHAR(7)       NOT NULL,
    FechaCorte       DATE          NOT NULL,
    SaldoAnterior    DECIMAL(12,2) NOT NULL,
    Compras          DECIMAL(12,2) NOT NULL,
    Pagos            DECIMAL(12,2) NOT NULL,
    Intereses        DECIMAL(12,2) NOT NULL,
    CargosComisiones DECIMAL(12,2) NOT NULL,
    SaldoCorte       DECIMAL(12,2) NOT NULL,
    PagoMinimo       DECIMAL(12,2) NOT NULL,
    FechaLimitePago  DATE          NOT NULL,
    DiasMora         SMALLINT      NOT NULL
);
GO
CREATE TABLE dbo.PagosTC (
    PagoID     INT IDENTITY(1,1) CONSTRAINT PK_PagosTC PRIMARY KEY,
    TarjetaID  INT           NOT NULL CONSTRAINT FK_PagoTC_Tarjeta REFERENCES dbo.TarjetasCredito(TarjetaID),
    FechaPago  DATE          NOT NULL,
    Monto      DECIMAL(12,2) NOT NULL,
    Canal      NVARCHAR(25)  NOT NULL
);
GO

""")
        inserts(f, "Clientes", CLI_COLS, CLIENTES)
        inserts(f, "ProductosTarjeta", ["ProductoID","Nombre","Marca","Categoria","LimiteMinimo","LimiteMaximo","TasaInteresAnual","CuotaAnual","BIN","ProgramaLealtad"],
                [[p[0], p[1], p[2], p[3], float(p[4]), float(p[5]), p[6], p[7], p[8], p[9]] for p in prods])
        inserts(f, "Comercios", ["ComercioID","Nombre","MCC","CategoriaMCC","Ciudad","Pais"], comercios)
        inserts(f, "TarjetasCredito", ["TarjetaID","ClienteID","ProductoID","PANEnmascarado","BIN","Ultimos4","FechaEmision","FechaVencimiento","LimiteCredito","SaldoActual","Estado","DiaCorte","DisponibleCompras","EsAdicional","TarjetaTitularID","PerfilPago","DiasMora"], tarjetas)
        inserts(f, "TransaccionesTC", ["TransaccionID","TarjetaID","ComercioID","FechaHora","TipoTransaccion","Monto","Moneda","Canal","NumeroCuotas","CodigoAutorizacion","Estado","MotivoRechazo"], tx_rows)
        inserts(f, "EstadosCuentaTC", ["EstadoCuentaID","TarjetaID","Periodo","FechaCorte","SaldoAnterior","Compras","Pagos","Intereses","CargosComisiones","SaldoCorte","PagoMinimo","FechaLimitePago","DiasMora"], ec_rows)
        inserts(f, "PagosTC", ["PagoID","TarjetaID","FechaPago","Monto","Canal"], pago_rows)
        f.write("""CREATE INDEX IX_TC_Cliente ON dbo.TarjetasCredito(ClienteID);
CREATE INDEX IX_TxTC_Tarjeta_Fecha ON dbo.TransaccionesTC(TarjetaID, FechaHora);
CREATE INDEX IX_EC_Tarjeta ON dbo.EstadosCuentaTC(TarjetaID, FechaCorte);
GO
CREATE VIEW dbo.vw_CarteraTarjetas AS
SELECT t.TarjetaID, c.DUI, c.Nombres + N' ' + c.Apellidos AS Cliente, c.Segmento,
       p.Nombre AS Producto, p.Marca, t.PANEnmascarado, t.Estado, t.LimiteCredito, t.SaldoActual,
       CAST(100.0 * t.SaldoActual / NULLIF(t.LimiteCredito,0) AS DECIMAL(6,2)) AS PorcentajeUso, t.DiasMora
FROM dbo.TarjetasCredito t
JOIN dbo.Clientes c ON c.ClienteID = t.ClienteID
JOIN dbo.ProductosTarjeta p ON p.ProductoID = t.ProductoID;
GO
""")
        footer(f, db, tablas)
    STATS[db] = {"Clientes": len(CLIENTES), "ProductosTarjeta": len(prods), "Comercios": len(comercios), "TarjetasCredito": len(tarjetas),
                 "TransaccionesTC": len(tx_rows), "EstadosCuentaTC": len(ec_rows), "PagosTC": len(pago_rows)}

# ============================================================ 2. DÉBITO / CUENTAS
def db_debito():
    rnd = random.Random(202)
    db = "BancaCuentasDebito"
    agencias = []
    for i in range(1, 41):
        dep = rnd.choices(list(DEPTOS), weights=DEPTO_PESOS)[0]
        mun = rnd.choice(DEPTOS[dep])
        tipo = rnd.choices(["Agencia","Mini agencia","Centro de negocios"], weights=[60, 30, 10])[0]
        agencias.append([i, f"{tipo} {mun} {i:02d}", tipo, dep, mun])
    atms = []
    for i in range(1, 181):
        dep = rnd.choices(list(DEPTOS), weights=DEPTO_PESOS)[0]
        mun = rnd.choice(DEPTOS[dep])
        ub = rnd.choice(["Centro comercial","Agencia","Gasolinera","Supermercado","Universidad","Hospital","Terminal de buses"])
        atms.append([i, f"ATM-{i:04d}", f"{ub} {mun}", dep, rnd.choices(["Propia","Compartida"], weights=[70, 30])[0], rnd.random() < 0.6])
    comercios = gen_comercios(rnd, 300)

    cuentas, tarjetas, movs, bloqueos = [], [], [], []
    cid = tdid = 0
    mov_tmp = []
    for cli in CLIENTES:
        if rnd.random() > 0.9: continue
        for k in range(rnd.choices([1, 2, 3], weights=[72, 23, 5])[0]):
            cid += 1
            tipo = "Ahorro" if k == 0 or rnd.random() < 0.6 else "Corriente"
            if cli[11] in ("Premium",) and k == 1: tipo = "Corriente"
            apertura = max(cli[12], HOY - D(days=rnd.randint(40, 12 * 365)))
            estado = rnd.choices(["Activa","Inactiva","Bloqueada","Cerrada"], weights=[86, 7, 2, 5])[0]
            num = ("1" if tipo == "Ahorro" else "2") + f"{rnd.randint(0, 99999999999):011d}"
            tasa = r2(rnd.choice([0.50, 0.75, 1.00, 1.50, 2.00])) if tipo == "Ahorro" else 0.0
            ag = rnd.randint(1, 40)
            saldo = r2(max(5, cli[10] * rnd.uniform(0.2, 4.0)))
            cuentas.append([cid, num, cli[0], tipo, "USD", saldo, tasa, apertura, estado, ag, None])
            td = None
            if estado != "Cerrada" and (tipo == "Ahorro" or rnd.random() < 0.4) and rnd.random() < 0.93:
                tdid += 1
                marca = rnd.choices(["Visa Débito","Mastercard Débito"], weights=[65, 35])[0]
                binv = "455501" if marca.startswith("Visa") else "526601"
                emis = max(apertura, HOY - D(days=rnd.randint(10, 5 * 365)))
                tdest = "Activa" if estado == "Activa" else ("Bloqueada" if estado == "Bloqueada" else "Inactiva")
                if tdest == "Activa" and rnd.random() < 0.04: tdest = rnd.choice(["Bloqueada","Reemplazada"])
                l4 = f"{rnd.randint(0, 9999):04d}"
                tarjetas.append([tdid, cid, binv + "******" + l4, marca, emis, add_months(emis, 48), 
                                 float(rnd.choice([300, 500, 750, 1000])), float(rnd.choice([1000, 1500, 2500, 5000])), tdest, rnd.random() < 0.7])
                td = tdid
                if tdest in ("Bloqueada", "Reemplazada") or rnd.random() < 0.05:
                    fb = rand_dt(rnd, HOY - D(days=300), HOY)
                    mot = rnd.choice(["Robo","Extravío","Sospecha de fraude","PIN bloqueado por intentos","Solicitud del cliente","Viaje no notificado"])
                    desb = tdest == "Activa"
                    bloqueos.append([td, fb, mot, rnd.choice(["App móvil","Call center","Agencia","Monitoreo de fraude"]), desb, fb + D(days=rnd.randint(1, 10)) if desb else None])
            # movimientos últimos 6 meses
            if estado in ("Cerrada", "Inactiva"): continue
            ini = max(apertura, HOY - D(days=183))
            eventos = []
            m = dt.date(ini.year, ini.month, 1)
            while m <= HOY:
                if k == 0 and rnd.random() < 0.85:
                    for dsal in (15, 30 if m.month != 2 else 28):
                        fd = dt.date(m.year, m.month, dsal)
                        if ini <= fd <= HOY:
                            eventos.append((dt.datetime(fd.year, fd.month, fd.day, rnd.randint(6, 9), rnd.randint(0, 59)), "Abono de planilla", r2(cli[10] / 2 * rnd.uniform(0.95, 1.0)), "Transferencia", None, None, None))
                for _ in range(rnd.randint(1, 5)):
                    f = rand_dt(rnd, max(m, ini), min(add_months(m, 1) - D(days=1), HOY))
                    tipo_m = rnd.choices(["Compra POS","Retiro ATM","Transferencia enviada","Transferencia recibida","Pago de servicio","Compra en línea","Depósito en efectivo"], weights=[34, 22, 12, 9, 10, 8, 5])[0]
                    atm = com = None
                    if tipo_m == "Retiro ATM":
                        monto = float(rnd.choice([20, 40, 60, 80, 100, 150, 200, 300])); canal = "ATM"; atm = rnd.randint(1, 180)
                    elif tipo_m in ("Compra POS", "Compra en línea"):
                        c = rnd.choice(comercios); mi = [x for x in MCC if x[0] == c[2]][0]
                        monto = r2(rnd.uniform(mi[3], mi[4] * 0.6)); canal = "POS" if tipo_m == "Compra POS" else "E-commerce"; com = c[1]
                    elif tipo_m == "Pago de servicio":
                        monto = r2(rnd.uniform(10, 120)); canal = rnd.choice(["App móvil","Banca en línea"]); com = rnd.choice(["Energía eléctrica","Agua potable","Telefonía","Internet residencial","Colegiatura"])
                    elif tipo_m == "Transferencia enviada":
                        monto = r2(rnd.uniform(10, max(20, cli[10] * 0.3))); canal = rnd.choice(["App móvil","Banca en línea","Transfer365"])
                    elif tipo_m == "Transferencia recibida":
                        monto = r2(rnd.uniform(10, 600)); canal = rnd.choice(["Transfer365","ACH","Remesa"])
                    else:
                        monto = r2(rnd.uniform(20, 800)); canal = "Agencia"
                    eventos.append((f, tipo_m, monto, canal, atm, com, td if tipo_m in ("Compra POS","Retiro ATM","Compra en línea") else None))
                m = add_months(m, 1)
            eventos.sort(key=lambda e: e[0])
            s = saldo
            for e in eventos:
                credito = e[1] in ("Abono de planilla","Transferencia recibida","Depósito en efectivo")
                if e[6] is None and e[1] in ("Compra POS","Retiro ATM","Compra en línea"): continue
                if not credito and e[2] > s: continue
                s = r2(s + e[2] if credito else s - e[2])
                mov_tmp.append([e[0], cid, e[6], e[1], "C" if credito else "D", e[2], s, e[3], e[4], e[5], f"REF{rnd.randint(10**9, 10**10 - 1)}"])
            cuentas[-1][5] = s
            cuentas[-1][10] = HOY if eventos else None
    mov_tmp.sort(key=lambda x: x[0])
    movs = [[i + 1, x[1], x[2], x[0]] + x[3:] for i, x in enumerate(mov_tmp)]
    bloqueos = [[i + 1] + b for i, b in enumerate(sorted(bloqueos, key=lambda b: b[1]))]
    for c in cuentas:
        c[10] = None
    last = {}
    for mv in movs: last[mv[1]] = mv[3].date()
    for c in cuentas: c[10] = last.get(c[0])

    tablas = ["Clientes","Agencias","CuentasDeposito","TarjetasDebito","CajerosATM","MovimientosCuenta","BloqueosTarjeta"]
    with open(f"{OUT}/02_BancaCuentasDebito.sql", "w", encoding="utf-8-sig") as f:
        header(f, db, "Cuentas de ahorro/corriente, tarjetas de débito, ATM, movimientos y bloqueos", ", ".join(tablas))
        f.write(CLI_DDL)
        f.write("""CREATE TABLE dbo.Agencias (
    AgenciaID    INT IDENTITY(1,1) CONSTRAINT PK_Agencias PRIMARY KEY,
    Nombre       NVARCHAR(80) NOT NULL,
    TipoAgencia  NVARCHAR(25) NOT NULL,
    Departamento NVARCHAR(40) NOT NULL,
    Municipio    NVARCHAR(60) NOT NULL
);
GO
CREATE TABLE dbo.CuentasDeposito (
    CuentaID          INT IDENTITY(1,1) CONSTRAINT PK_CuentasDeposito PRIMARY KEY,
    NumeroCuenta      CHAR(12)      NOT NULL CONSTRAINT UQ_Cuentas_Numero UNIQUE,
    ClienteID         INT           NOT NULL CONSTRAINT FK_Cta_Cliente REFERENCES dbo.Clientes(ClienteID),
    TipoCuenta        NVARCHAR(15)  NOT NULL CONSTRAINT CK_Cta_Tipo CHECK (TipoCuenta IN (N'Ahorro',N'Corriente')),
    Moneda            CHAR(3)       NOT NULL,
    SaldoDisponible   DECIMAL(14,2) NOT NULL,
    TasaInteresAnual  DECIMAL(5,2)  NOT NULL,
    FechaApertura     DATE          NOT NULL,
    Estado            NVARCHAR(15)  NOT NULL,
    AgenciaID         INT           NOT NULL CONSTRAINT FK_Cta_Agencia REFERENCES dbo.Agencias(AgenciaID),
    FechaUltimoMovimiento DATE      NULL
);
GO
CREATE TABLE dbo.TarjetasDebito (
    TarjetaDebitoID   INT IDENTITY(1,1) CONSTRAINT PK_TarjetasDebito PRIMARY KEY,
    CuentaID          INT           NOT NULL CONSTRAINT FK_TD_Cuenta REFERENCES dbo.CuentasDeposito(CuentaID),
    PANEnmascarado    CHAR(16)      NOT NULL,
    Marca             NVARCHAR(25)  NOT NULL,
    FechaEmision      DATE          NOT NULL,
    FechaVencimiento  DATE          NOT NULL,
    LimiteDiarioATM   DECIMAL(10,2) NOT NULL,
    LimiteDiarioPOS   DECIMAL(10,2) NOT NULL,
    Estado            NVARCHAR(15)  NOT NULL,
    Contactless       BIT           NOT NULL
);
GO
CREATE TABLE dbo.CajerosATM (
    ATMID        INT IDENTITY(1,1) CONSTRAINT PK_CajerosATM PRIMARY KEY,
    CodigoATM    VARCHAR(10)   NOT NULL,
    Ubicacion    NVARCHAR(100) NOT NULL,
    Departamento NVARCHAR(40)  NOT NULL,
    Red          NVARCHAR(15)  NOT NULL,
    AceptaDeposito BIT         NOT NULL
);
GO
CREATE TABLE dbo.MovimientosCuenta (
    MovimientoID     BIGINT IDENTITY(1,1) CONSTRAINT PK_MovimientosCuenta PRIMARY KEY,
    CuentaID         INT           NOT NULL CONSTRAINT FK_Mov_Cuenta REFERENCES dbo.CuentasDeposito(CuentaID),
    TarjetaDebitoID  INT           NULL CONSTRAINT FK_Mov_TD REFERENCES dbo.TarjetasDebito(TarjetaDebitoID),
    FechaHora        DATETIME2(0)  NOT NULL,
    TipoMovimiento   NVARCHAR(30)  NOT NULL,
    Naturaleza       CHAR(1)       NOT NULL CONSTRAINT CK_Mov_Nat CHECK (Naturaleza IN ('C','D')),
    Monto            DECIMAL(12,2) NOT NULL,
    SaldoPosterior   DECIMAL(14,2) NOT NULL,
    Canal            NVARCHAR(20)  NOT NULL,
    ATMID            INT           NULL CONSTRAINT FK_Mov_ATM REFERENCES dbo.CajerosATM(ATMID),
    Descripcion      NVARCHAR(100) NULL,
    Referencia       VARCHAR(20)   NOT NULL
);
GO
CREATE TABLE dbo.BloqueosTarjeta (
    BloqueoID        INT IDENTITY(1,1) CONSTRAINT PK_BloqueosTarjeta PRIMARY KEY,
    TarjetaDebitoID  INT           NOT NULL CONSTRAINT FK_Bloq_TD REFERENCES dbo.TarjetasDebito(TarjetaDebitoID),
    FechaBloqueo     DATETIME2(0)  NOT NULL,
    Motivo           NVARCHAR(40)  NOT NULL,
    CanalSolicitud   NVARCHAR(25)  NOT NULL,
    Desbloqueada     BIT           NOT NULL,
    FechaDesbloqueo  DATETIME2(0)  NULL
);
GO

""")
        inserts(f, "Clientes", CLI_COLS, CLIENTES)
        inserts(f, "Agencias", ["AgenciaID","Nombre","TipoAgencia","Departamento","Municipio"], agencias)
        inserts(f, "CuentasDeposito", ["CuentaID","NumeroCuenta","ClienteID","TipoCuenta","Moneda","SaldoDisponible","TasaInteresAnual","FechaApertura","Estado","AgenciaID","FechaUltimoMovimiento"], cuentas)
        inserts(f, "TarjetasDebito", ["TarjetaDebitoID","CuentaID","PANEnmascarado","Marca","FechaEmision","FechaVencimiento","LimiteDiarioATM","LimiteDiarioPOS","Estado","Contactless"], tarjetas)
        inserts(f, "CajerosATM", ["ATMID","CodigoATM","Ubicacion","Departamento","Red","AceptaDeposito"], atms)
        inserts(f, "MovimientosCuenta", ["MovimientoID","CuentaID","TarjetaDebitoID","FechaHora","TipoMovimiento","Naturaleza","Monto","SaldoPosterior","Canal","ATMID","Descripcion","Referencia"], movs)
        inserts(f, "BloqueosTarjeta", ["BloqueoID","TarjetaDebitoID","FechaBloqueo","Motivo","CanalSolicitud","Desbloqueada","FechaDesbloqueo"], bloqueos)
        f.write("""CREATE INDEX IX_Cta_Cliente ON dbo.CuentasDeposito(ClienteID);
CREATE INDEX IX_Mov_Cuenta_Fecha ON dbo.MovimientosCuenta(CuentaID, FechaHora);
GO
CREATE VIEW dbo.vw_ResumenCuentas AS
SELECT c.CuentaID, c.NumeroCuenta, cl.DUI, cl.Nombres + N' ' + cl.Apellidos AS Cliente, c.TipoCuenta, c.Estado,
       c.SaldoDisponible, td.PANEnmascarado, td.Marca, td.Estado AS EstadoTarjeta
FROM dbo.CuentasDeposito c
JOIN dbo.Clientes cl ON cl.ClienteID = c.ClienteID
LEFT JOIN dbo.TarjetasDebito td ON td.CuentaID = c.CuentaID;
GO
""")
        footer(f, db, tablas)
    STATS[db] = {"Clientes": len(CLIENTES), "Agencias": len(agencias), "CuentasDeposito": len(cuentas), "TarjetasDebito": len(tarjetas),
                 "CajerosATM": len(atms), "MovimientosCuenta": len(movs), "BloqueosTarjeta": len(bloqueos)}

# ============================================================ 3. TOKENIZACIÓN
def db_tokenizacion():
    rnd = random.Random(303)
    db = "BancaTokenizacion"
    proveedores = [[1, "Visa Token Service", "VTS", "Visa"], [2, "Mastercard Digital Enablement Service", "MDES", "Mastercard"]]
    wallets = [  # id, nombre, tipo dominio, requestor id
        [1, "Apple Pay", "Billetera móvil (NFC)", "40010030273"],
        [2, "Google Pay", "Billetera móvil (NFC/HCE)", "40010075001"],
        [3, "Samsung Pay", "Billetera móvil (NFC/MST)", "40010043095"],
        [4, "Garmin Pay", "Wearable (NFC)", "40010077056"],
        [5, "Click to Pay", "Comercio electrónico", "40010099010"],
        [6, "Card on File - Plataforma Streaming", "Comercio (COF)", "40011111001"],
        [7, "Card on File - Marketplace", "Comercio (COF)", "40011111002"],
        [8, "Card on File - App de transporte", "Comercio (COF)", "40011111003"],
        [9, "Card on File - Telefonía", "Comercio (COF)", "40011111004"],
        [10, "Billetera App Banca Móvil", "Billetera emisor (HCE)", "40019999001"],
    ]
    devs_models = {"iOS": ["iPhone 13","iPhone 14","iPhone 15","iPhone 15 Pro","iPhone 16","iPhone 17","Apple Watch S9"],
                   "Android": ["Galaxy S23","Galaxy S24","Galaxy A54","Galaxy A35","Pixel 8","Pixel 9","Redmi Note 13","Moto G84"],
                   "Garmin OS": ["Venu 3","Forerunner 265"]}
    tarjetas, dispositivos, tokens, eventos, txs = [], [], [], [], []
    tid = did = tkid = 0
    cli_devs = {}
    comercios_tok = ["Supermercado La Económica","Café Volcán","Gasolinera Central","Farmacia Salud Total","Pizza Nostra","Tienda Online Global",
                     "Plataforma Streaming","Marketplace Express","Movilidad Express","Telefonía Móvil SV","Cinema Plaza","Burger Planet"]
    for cli in CLIENTES:
        if rnd.random() > 0.72: continue
        # dispositivos
        nd = rnd.choices([1, 2, 3], weights=[65, 28, 7])[0]
        so_pref = rnd.choices(["iOS", "Android"], weights=[42, 58])[0]
        devs = []
        for j in range(nd):
            did += 1
            so = so_pref if j == 0 else rnd.choices([so_pref, "Garmin OS"], weights=[85, 15])[0]
            modelo = rnd.choice(devs_models[so])
            tipo = "Reloj" if ("Watch" in modelo or so == "Garmin OS") else "Teléfono"
            fp = hashlib.sha256(f"dev{did}".encode()).hexdigest()[:32].upper()
            reg = HOY - D(days=rnd.randint(5, 4 * 365))
            dispositivos.append([did, cli[0], tipo, so, modelo, fp, reg, rnd.random() < 0.97])
            devs.append((did, so))
        for k in range(rnd.choices([1, 2], weights=[75, 25])[0]):
            tid += 1
            marca = rnd.choices(["Visa", "Mastercard"], weights=[62, 38])[0]
            tipo_t = rnd.choices(["Crédito", "Débito"], weights=[55, 45])[0]
            binv = {("Visa","Crédito"): "400034", ("Visa","Débito"): "455501", ("Mastercard","Crédito"): "510022", ("Mastercard","Débito"): "526601"}[(marca, tipo_t)]
            l4 = f"{rnd.randint(0, 9999):04d}"
            est_t = rnd.choices(["Activa","Bloqueada","Cancelada"], weights=[90, 5, 5])[0]
            tarjetas.append([tid, cli[0], binv + "******" + l4, marca, tipo_t, est_t, add_months(HOY, rnd.randint(3, 59))])
            prov = 1 if marca == "Visa" else 2
            # tokens
            cand = []
            for (d_id, so) in devs:
                if so == "iOS": cand.append((1, d_id))
                elif so == "Android": cand.append((rnd.choice([2, 2, 3, 10]), d_id))
                else: cand.append((4, d_id))
            for w in rnd.sample([5, 6, 7, 8, 9], rnd.randint(0, 3)): cand.append((w, None))
            for (w, d_id) in cand:
                if rnd.random() < 0.18: continue
                tkid += 1
                prov_dt = rand_dt(rnd, HOY - D(days=3 * 365), HOY - D(days=1))
                tbin = "489537" if marca == "Visa" else "522250"
                tok_l4 = f"{rnd.randint(0, 9999):04d}"
                ref = ("DNITHE" if prov == 1 else "DM4MMC") + hashlib.md5(f"tk{tkid}".encode()).hexdigest()[:20].upper()
                verif = rnd.choices(["Green path (sin desafío)","OTP SMS","OTP Email","App Banca Móvil","Call Center"], weights=[45, 30, 5, 15, 5])[0]
                estado = "Activo"
                evs = [(prov_dt, "Solicitud de provisión", "Wallet"), (prov_dt + D(seconds=rnd.randint(2, 40)), "Decisión: aprobado" if verif.startswith("Green") else "Decisión: requiere verificación", "Emisor")]
                if not verif.startswith("Green"):
                    if rnd.random() < 0.08:
                        evs.append((prov_dt + D(minutes=rnd.randint(1, 30)), "Verificación fallida", "Cliente"))
                        estado = "Eliminado"
                    else:
                        evs.append((prov_dt + D(minutes=rnd.randint(1, 10)), "Verificación exitosa (" + verif + ")", "Cliente"))
                if estado == "Activo":
                    evs.append((evs[-1][0] + D(seconds=rnd.randint(1, 20)), "Token activado", "TSP"))
                    r = rnd.random()
                    if est_t == "Cancelada" or r < 0.07:
                        evs.append((rand_dt(rnd, evs[-1][0].date(), HOY), "Token eliminado", rnd.choice(["Emisor","Cliente","Wallet"])))
                        estado = "Eliminado"
                    elif est_t == "Bloqueada" or r < 0.12:
                        evs.append((rand_dt(rnd, evs[-1][0].date(), HOY), "Token suspendido", rnd.choice(["Emisor","Monitoreo de fraude","Cliente"])))
                        estado = "Suspendido"
                        if est_t == "Activa" and rnd.random() < 0.5:
                            evs.append((evs[-1][0] + D(days=rnd.randint(1, 15)), "Token reanudado", "Emisor"))
                            estado = "Activo"
                    if rnd.random() < 0.10:
                        evs.append((rand_dt(rnd, evs[2][0].date(), HOY), "Actualización de PAN/vencimiento (LCM)", "Emisor"))
                evs = [e for e in evs if e[0].date() <= HOY]
                evs.sort(key=lambda e: e[0])
                for e in evs: eventos.append([e[0], tkid, e[1], e[2]])
                nivel = "Alto" if verif.startswith("App") else ("Medio" if "OTP" in verif or "Call" in verif else "Estándar")
                tokens.append([tkid, ref, tbin + "******" + tok_l4, tid, w, prov, d_id, wallets[w - 1][3], prov_dt, add_months(prov_dt.date(), 36), estado, verif, nivel])
                # transacciones
                if estado == "Eliminado" and len(evs) < 4: continue
                act = [e for e in evs if e[1] == "Token activado"]
                if not act: continue
                fin_t = evs[-1][0].date() if estado != "Activo" else HOY
                ini_t = max(act[0][0].date(), HOY - D(days=365))
                if ini_t > fin_t: continue
                nt = rnd.randint(1, 22) if w in (1, 2, 3, 10) else rnd.randint(1, 12)
                for _ in range(nt):
                    f = rand_dt(rnd, ini_t, fin_t)
                    if w in (1, 2, 3, 4, 10):
                        canal = rnd.choices(["NFC presencial","In-App"], weights=[78, 22])[0]
                        com = rnd.choice(comercios_tok[:6] + comercios_tok[10:])
                        eci = "05" if canal == "In-App" else None
                        monto = r2(rnd.uniform(1.5, 120))
                    elif w == 5:
                        canal, com, eci, monto = "E-commerce", rnd.choice(["Tienda Online Global","Marketplace Express","Aerolínea Centroamericana","Hotel Pacífico"]), "05", r2(rnd.uniform(10, 450))
                    else:
                        canal = "Recurrente COF" if w in (6, 9) else "E-commerce COF"
                        com = {6: "Plataforma Streaming", 7: "Marketplace Express", 8: "Movilidad Express", 9: "Telefonía Móvil SV"}[w]
                        eci = "07"
                        monto = r2(rnd.choice([7.99, 9.99, 12.99, 15.49]) if w == 6 else (rnd.choice([15.0, 20.0, 25.0, 35.0]) if w == 9 else rnd.uniform(3, 180)))
                    crip = "Válido" if rnd.random() > 0.01 else "Inválido"
                    motivo = None
                    if crip == "Inválido": motivo = "Criptograma inválido"
                    elif rnd.random() < 0.035: motivo = rnd.choice(["Fondos insuficientes","Sospecha de fraude","Token suspendido","Excede límite"])
                    txs.append([f, tkid, com, canal, monto, "USD", crip, eci, "Rechazada" if motivo else "Aprobada", motivo,
                                f"{rnd.randint(0, 999999):06d}" if not motivo else None])
    txs.sort(key=lambda x: x[0])
    tx_rows = [[i + 1, x[1], x[0]] + x[2:] for i, x in enumerate(txs)]
    eventos.sort(key=lambda e: e[0])
    ev_rows = [[i + 1, e[1], e[0], e[2], e[3]] for i, e in enumerate(eventos)]

    tablas = ["Clientes","ProveedoresToken","Wallets","TarjetasOrigen","Dispositivos","Tokens","EventosCicloVidaToken","TransaccionesTokenizadas"]
    with open(f"{OUT}/03_BancaTokenizacion.sql", "w", encoding="utf-8-sig") as f:
        header(f, db, "Tokenización (VTS/MDES): wallets, dispositivos, tokens, ciclo de vida y transacciones tokenizadas", ", ".join(tablas))
        f.write(CLI_DDL)
        f.write("""CREATE TABLE dbo.ProveedoresToken (
    ProveedorID  INT IDENTITY(1,1) CONSTRAINT PK_ProveedoresToken PRIMARY KEY,
    Nombre       NVARCHAR(60) NOT NULL,
    Sigla        VARCHAR(10)  NOT NULL,
    Marca        NVARCHAR(20) NOT NULL
);
GO
CREATE TABLE dbo.Wallets (
    WalletID          INT IDENTITY(1,1) CONSTRAINT PK_Wallets PRIMARY KEY,
    Nombre            NVARCHAR(60) NOT NULL,
    DominioToken      NVARCHAR(40) NOT NULL,
    TokenRequestorID  CHAR(11)     NOT NULL
);
GO
CREATE TABLE dbo.TarjetasOrigen (
    TarjetaID        INT IDENTITY(1,1) CONSTRAINT PK_TarjetasOrigen PRIMARY KEY,
    ClienteID        INT          NOT NULL CONSTRAINT FK_TO_Cliente REFERENCES dbo.Clientes(ClienteID),
    PANEnmascarado   CHAR(16)     NOT NULL,
    Marca            NVARCHAR(20) NOT NULL,
    TipoTarjeta      NVARCHAR(10) NOT NULL,
    Estado           NVARCHAR(15) NOT NULL,
    FechaVencimiento DATE         NOT NULL
);
GO
CREATE TABLE dbo.Dispositivos (
    DispositivoID     INT IDENTITY(1,1) CONSTRAINT PK_Dispositivos PRIMARY KEY,
    ClienteID         INT          NOT NULL CONSTRAINT FK_Disp_Cliente REFERENCES dbo.Clientes(ClienteID),
    TipoDispositivo   NVARCHAR(15) NOT NULL,
    SistemaOperativo  NVARCHAR(15) NOT NULL,
    Modelo            NVARCHAR(40) NOT NULL,
    DeviceFingerprint CHAR(32)     NOT NULL,
    FechaRegistro     DATE         NOT NULL,
    Confiable         BIT          NOT NULL
);
GO
CREATE TABLE dbo.Tokens (
    TokenID              INT IDENTITY(1,1) CONSTRAINT PK_Tokens PRIMARY KEY,
    TokenReferenceID     VARCHAR(30)  NOT NULL CONSTRAINT UQ_Tokens_Ref UNIQUE,
    TokenEnmascarado     CHAR(16)     NOT NULL,
    TarjetaID            INT          NOT NULL CONSTRAINT FK_Tok_Tarjeta REFERENCES dbo.TarjetasOrigen(TarjetaID),
    WalletID             INT          NOT NULL CONSTRAINT FK_Tok_Wallet REFERENCES dbo.Wallets(WalletID),
    ProveedorID          INT          NOT NULL CONSTRAINT FK_Tok_Prov REFERENCES dbo.ProveedoresToken(ProveedorID),
    DispositivoID        INT          NULL CONSTRAINT FK_Tok_Disp REFERENCES dbo.Dispositivos(DispositivoID),
    TokenRequestorID     CHAR(11)     NOT NULL,
    FechaProvision       DATETIME2(0) NOT NULL,
    FechaVencimientoToken DATE        NOT NULL,
    Estado               NVARCHAR(15) NOT NULL,
    MetodoVerificacion   NVARCHAR(30) NOT NULL,
    NivelAseguramiento   NVARCHAR(10) NOT NULL
);
GO
CREATE TABLE dbo.EventosCicloVidaToken (
    EventoID   BIGINT IDENTITY(1,1) CONSTRAINT PK_EventosToken PRIMARY KEY,
    TokenID    INT           NOT NULL CONSTRAINT FK_Ev_Token REFERENCES dbo.Tokens(TokenID),
    FechaHora  DATETIME2(0)  NOT NULL,
    Evento     NVARCHAR(60)  NOT NULL,
    Origen     NVARCHAR(25)  NOT NULL
);
GO
CREATE TABLE dbo.TransaccionesTokenizadas (
    TransaccionID      BIGINT IDENTITY(1,1) CONSTRAINT PK_TxTok PRIMARY KEY,
    TokenID            INT           NOT NULL CONSTRAINT FK_TxTok_Token REFERENCES dbo.Tokens(TokenID),
    FechaHora          DATETIME2(0)  NOT NULL,
    Comercio           NVARCHAR(80)  NOT NULL,
    Canal              NVARCHAR(25)  NOT NULL,
    Monto              DECIMAL(12,2) NOT NULL,
    Moneda             CHAR(3)       NOT NULL,
    ValidacionCriptograma NVARCHAR(10) NOT NULL,
    ECI                CHAR(2)       NULL,
    Estado             NVARCHAR(12)  NOT NULL,
    MotivoRechazo      NVARCHAR(40)  NULL,
    CodigoAutorizacion CHAR(6)       NULL
);
GO

""")
        inserts(f, "Clientes", CLI_COLS, CLIENTES)
        inserts(f, "ProveedoresToken", ["ProveedorID","Nombre","Sigla","Marca"], proveedores)
        inserts(f, "Wallets", ["WalletID","Nombre","DominioToken","TokenRequestorID"], wallets)
        inserts(f, "TarjetasOrigen", ["TarjetaID","ClienteID","PANEnmascarado","Marca","TipoTarjeta","Estado","FechaVencimiento"], tarjetas)
        inserts(f, "Dispositivos", ["DispositivoID","ClienteID","TipoDispositivo","SistemaOperativo","Modelo","DeviceFingerprint","FechaRegistro","Confiable"], dispositivos)
        inserts(f, "Tokens", ["TokenID","TokenReferenceID","TokenEnmascarado","TarjetaID","WalletID","ProveedorID","DispositivoID","TokenRequestorID","FechaProvision","FechaVencimientoToken","Estado","MetodoVerificacion","NivelAseguramiento"], tokens)
        inserts(f, "EventosCicloVidaToken", ["EventoID","TokenID","FechaHora","Evento","Origen"], ev_rows)
        inserts(f, "TransaccionesTokenizadas", ["TransaccionID","TokenID","FechaHora","Comercio","Canal","Monto","Moneda","ValidacionCriptograma","ECI","Estado","MotivoRechazo","CodigoAutorizacion"], tx_rows)
        f.write("""CREATE INDEX IX_Tok_Tarjeta ON dbo.Tokens(TarjetaID);
CREATE INDEX IX_TxTok_Token_Fecha ON dbo.TransaccionesTokenizadas(TokenID, FechaHora);
CREATE INDEX IX_Ev_Token ON dbo.EventosCicloVidaToken(TokenID, FechaHora);
GO
CREATE VIEW dbo.vw_TokensPorWallet AS
SELECT w.Nombre AS Wallet, p.Sigla AS TSP, t.Estado, COUNT(*) AS Tokens
FROM dbo.Tokens t
JOIN dbo.Wallets w ON w.WalletID = t.WalletID
JOIN dbo.ProveedoresToken p ON p.ProveedorID = t.ProveedorID
GROUP BY w.Nombre, p.Sigla, t.Estado;
GO
""")
        footer(f, db, tablas)
    STATS[db] = {"Clientes": len(CLIENTES), "ProveedoresToken": 2, "Wallets": len(wallets), "TarjetasOrigen": len(tarjetas), "Dispositivos": len(dispositivos),
                 "Tokens": len(tokens), "EventosCicloVidaToken": len(ev_rows), "TransaccionesTokenizadas": len(tx_rows)}

# ============================================================ 4. LEASING
def db_leasing():
    rnd = random.Random(404)
    db = "BancaLeasing"
    giros = ["Transporte de carga","Construcción","Distribución de alimentos","Servicios médicos","Agroindustria","Manufactura textil","Logística","Comercio mayorista","Tecnología","Turismo"]
    sufijos = ["S.A. de C.V.","S.A.","S.A. de C.V.","Ltda. de C.V."]
    raices = ["Inversiones","Grupo","Distribuidora","Transportes","Constructora","Servicios","Agroindustrias","Logística","Comercial","Industrias","Tecnologías","Clínica"]
    nombres_emp = ["Cuscatlán","Del Pacífico","Izalco","Lempa","Centroamericana","Los Volcanes","San Andrés","El Boquerón","Maya","Jaguar","Real","Atlas","Continental","Guazapa","Tecana","Ilopango","Del Norte","Sol","Rivera","Ceiba"]
    arr = []
    nits = set()
    for i in range(1, 1301):
        if rnd.random() < 0.55:
            cli = CLIENTES[rnd.randint(0, len(CLIENTES) - 1)]
            arr.append([i, "Natural", f"{cli[2]} {cli[3]}", cli[1], None, cli[8], cli[9], cli[6], cli[7], r2(cli[10] * 12)])
        else:
            while True:
                nit = f"0614-{rnd.randint(10000, 311299):06d}-{rnd.randint(100, 199)}-{rnd.randint(0, 9)}"
                if nit not in nits: nits.add(nit); break
            dep = rnd.choices(list(DEPTOS), weights=DEPTO_PESOS)[0]
            nom = f"{rnd.choice(raices)} {rnd.choice(nombres_emp)} {rnd.choice(sufijos)}"
            arr.append([i, "Jurídica", nom, nit, rnd.choice(giros), dep, rnd.choice(DEPTOS[dep]),
                        "contacto@" + unaccent(nom.split()[1]).lower() + f"{i}.com.sv", f"2{rnd.randint(100, 999)}-{rnd.randint(0, 9999):04d}", r2(rnd.uniform(150000, 12000000))])
    proveedores = []
    tipos_prov = [("Concesionario de vehículos", ["Autos del Pacífico","Motores Centroamérica","Auto Plaza SV","Grupo Automotriz Volcán","Camiones y Equipos del Sur"]),
                  ("Maquinaria pesada", ["Maquinaria Industrial CA","Equipos de Construcción Lempa","Tractores y Más"]),
                  ("Equipo médico", ["MedTec Centroamérica","Equipos Hospitalarios SV"]),
                  ("Tecnología", ["Soluciones TI Cuscatlán","DataCenter Pro","Ofimática Total"]),
                  ("Equipo industrial", ["Industrias y Montajes","Refrigeración Comercial SV","Montacargas Express"])]
    pid = 0
    for t, ns in tipos_prov:
        for n in ns:
            pid += 1
            proveedores.append([pid, n + " S.A. de C.V.", t, f"0614-{rnd.randint(10000, 311299):06d}-{rnd.randint(100, 199)}-{rnd.randint(0, 9)}"])
    prov_by_tipo = {}
    for p in proveedores: prov_by_tipo.setdefault(p[2], []).append(p[0])
    catalogo = [  # tipo activo, tipo proveedor, marcas/modelos, valor min, max, vida, peso
        ("Vehículo liviano", "Concesionario de vehículos", [("Toyota","Hilux"),("Toyota","Corolla Cross"),("Nissan","Frontier"),("Hyundai","Tucson"),("Kia","Sportage"),("Mazda","CX-5"),("Mitsubishi","L200"),("Chevrolet","Captiva")], 18000, 55000, 60, 40),
        ("Camión / Transporte", "Concesionario de vehículos", [("Hino","300 Series"),("Isuzu","NPR"),("Freightliner","M2 106"),("International","MV607"),("JAC","N-Series")], 35000, 140000, 72, 14),
        ("Maquinaria pesada", "Maquinaria pesada", [("Caterpillar","420 Retroexcavadora"),("John Deere","310L"),("Komatsu","PC200"),("Bobcat","S650"),("Case","580N")], 60000, 260000, 72, 10),
        ("Equipo médico", "Equipo médico", [("Siemens","Tomógrafo Somatom"),("GE","Ultrasonido Logiq"),("Philips","Monitor IntelliVue"),("Mindray","Rayos X DigiEye")], 15000, 220000, 60, 8),
        ("Equipo de cómputo", "Tecnología", [("Dell","Servidores PowerEdge"),("HP","Lote Laptops ProBook"),("Lenovo","Lote ThinkPad"),("Cisco","Equipo de red Catalyst")], 8000, 90000, 36, 14),
        ("Equipo industrial", "Equipo industrial", [("Toyota","Montacargas 8FGU25"),("Carrier","Cuarto frío"),("Atlas Copco","Compresor GA"),("Hyster","Montacargas H50")], 12000, 120000, 60, 14),
    ]
    activos, contratos, cuotas, seguros = [], [], [], []
    aseguradoras = ["Aseguradora Cuscatlán","Seguros del Pacífico","Aseguradora Centroamericana","Seguros Volcán","Previsión y Seguros SV"]
    cuo_id = 0
    for cid in range(1, 1701):
        a = rnd.choice(arr)
        cat = rnd.choices(catalogo, weights=[c[6] for c in catalogo])[0]
        if a[1] == "Natural": cat = catalogo[0] if rnd.random() < 0.85 else catalogo[4]
        marca, modelo = rnd.choice(cat[2])
        anio = rnd.randint(2019, 2027)
        valor = r2(round(rnd.uniform(cat[3], cat[4]) / 100) * 100)
        serie = ("VIN" if "Vehículo" in cat[0] or "Camión" in cat[0] else "SER") + hashlib.md5(f"a{cid}".encode()).hexdigest()[:14].upper()
        activos.append([cid, cat[0], marca, modelo, anio, serie, valor, rnd.choice(prov_by_tipo[cat[1]]), "Nuevo" if anio >= 2024 else rnd.choice(["Nuevo","Seminuevo"])])
        tipo_l = rnd.choices(["Financiero","Operativo"], weights=[75, 25])[0]
        inicio = HOY - D(days=rnd.randint(-20, 6 * 365))
        inicio = dt.date(inicio.year, inicio.month, rnd.choice([1, 5, 10, 15, 20, 25]))
        plazo = rnd.choice([24, 36, 48, 60, 72] if cat[5] >= 60 else [24, 36])
        prima_pct = rnd.choice([0, 10, 15, 20, 25, 30]) if tipo_l == "Financiero" else 0
        residual_pct = rnd.choice([1, 5, 10]) if tipo_l == "Financiero" else rnd.choice([20, 25, 30, 35])
        tasa = r2(rnd.uniform(8.5, 14.5))
        financiado = r2(valor * (1 - prima_pct / 100))
        residual = r2(valor * residual_pct / 100)
        r = tasa / 1200
        cuota = r2((financiado - residual / (1 + r) ** plazo) * r / (1 - (1 + r) ** -plazo))
        seguro_m = r2(valor * rnd.uniform(0.025, 0.045) / 12)
        comport = rnd.choices(["Puntual","Tardío","Moroso"], weights=[70, 22, 8])[0]
        saldo = financiado
        vencidas = 0
        mora_max = 0
        pagadas = 0
        for k in range(1, plazo + 1):
            fv = add_months(inicio, k)
            interes = r2(saldo * r)
            capital = r2(cuota - interes)
            saldo = r2(saldo - capital)
            iva = r2(cuota * 0.13)
            total = r2(cuota + iva + seguro_m)
            fpago = mp = None
            dm = 0
            if fv <= HOY:
                if comport == "Moroso" and fv > HOY - D(days=rnd.choice([35, 65, 95, 125])):
                    est = "Vencida"; dm = (HOY - fv).days; vencidas += 1
                else:
                    atraso = 0 if comport == "Puntual" else rnd.choice([0, 0, 2, 5, 9, 15, 22]) if comport == "Tardío" else rnd.choice([0, 5, 12, 30])
                    fpago = fv + D(days=atraso - (rnd.randint(0, 5) if atraso == 0 else 0))
                    if fpago > HOY: fpago = HOY
                    dm = max(0, (fpago - fv).days)
                    mp = total if dm == 0 else r2(total + total * 0.0005 * dm)
                    est = "Pagada"; pagadas += 1
                mora_max = max(mora_max, dm)
            else:
                est = "Pendiente"
            cuo_id += 1
            cuotas.append([cuo_id, cid, k, fv, capital, interes, iva, seguro_m, total, fpago, mp, est, dm])
        fin = add_months(inicio, plazo)
        if inicio > HOY: est_c = "Aprobado - por activar"
        elif fin <= HOY and vencidas == 0: est_c = "Finalizado"
        elif vencidas > 0: est_c = "En mora"
        else: est_c = "Vigente"
        opcion = None
        if tipo_l == "Financiero" and est_c == "Finalizado": opcion = rnd.choices(["Ejercida","No ejercida"], weights=[88, 12])[0]
        num = f"LS-{inicio.year}-{cid:06d}"
        saldo_pend = r2(sum(c[4] for c in cuotas[-plazo:] if c[11] != "Pagada"))
        contratos.append([cid, num, a[0], cid, tipo_l, inicio, plazo, valor, float(prima_pct), financiado, tasa, residual, cuota, est_c, opcion, saldo_pend, max([c[12] for c in cuotas[-plazo:] if c[11] == "Vencida"] or [0])])
        seguros.append([cid, cid, rnd.choice(aseguradoras), f"POL-{rnd.randint(100000, 999999)}", "Todo riesgo" if "Vehículo" in cat[0] or "Camión" in cat[0] else "Daño físico y robo",
                        r2(seguro_m * 12), inicio, add_months(inicio, 12 * math.ceil(plazo / 12))])

    tablas = ["Arrendatarios","ProveedoresActivo","Activos","ContratosLeasing","CuotasLeasing","SegurosActivo"]
    with open(f"{OUT}/04_BancaLeasing.sql", "w", encoding="utf-8-sig") as f:
        header(f, db, "Arrendamiento financiero y operativo: arrendatarios, proveedores, activos, contratos, cuotas (con IVA) y seguros", ", ".join(tablas))
        f.write("""CREATE TABLE dbo.Arrendatarios (
    ArrendatarioID  INT IDENTITY(1,1) CONSTRAINT PK_Arrendatarios PRIMARY KEY,
    TipoPersona     NVARCHAR(10)  NOT NULL CONSTRAINT CK_Arr_Tipo CHECK (TipoPersona IN (N'Natural',N'Jurídica')),
    NombreRazonSocial NVARCHAR(120) NOT NULL,
    Documento       VARCHAR(20)   NOT NULL,   -- DUI (natural) o NIT (jurídica)
    GiroEconomico   NVARCHAR(40)  NULL,
    Departamento    NVARCHAR(40)  NOT NULL,
    Municipio       NVARCHAR(60)  NOT NULL,
    Email           NVARCHAR(120) NULL,
    Telefono        VARCHAR(15)   NULL,
    IngresoAnual    DECIMAL(14,2) NOT NULL
);
GO
CREATE TABLE dbo.ProveedoresActivo (
    ProveedorID   INT IDENTITY(1,1) CONSTRAINT PK_ProveedoresActivo PRIMARY KEY,
    Nombre        NVARCHAR(100) NOT NULL,
    TipoProveedor NVARCHAR(40)  NOT NULL,
    NIT           VARCHAR(20)   NOT NULL
);
GO
CREATE TABLE dbo.Activos (
    ActivoID     INT IDENTITY(1,1) CONSTRAINT PK_Activos PRIMARY KEY,
    TipoActivo   NVARCHAR(30)  NOT NULL,
    Marca        NVARCHAR(30)  NOT NULL,
    Modelo       NVARCHAR(40)  NOT NULL,
    Anio         SMALLINT      NOT NULL,
    NumeroSerieVIN VARCHAR(20) NOT NULL,
    ValorCompra  DECIMAL(14,2) NOT NULL,
    ProveedorID  INT           NOT NULL CONSTRAINT FK_Act_Prov REFERENCES dbo.ProveedoresActivo(ProveedorID),
    Condicion    NVARCHAR(12)  NOT NULL
);
GO
CREATE TABLE dbo.ContratosLeasing (
    ContratoID      INT IDENTITY(1,1) CONSTRAINT PK_ContratosLeasing PRIMARY KEY,
    NumeroContrato  VARCHAR(20)   NOT NULL CONSTRAINT UQ_Contrato UNIQUE,
    ArrendatarioID  INT           NOT NULL CONSTRAINT FK_Con_Arr REFERENCES dbo.Arrendatarios(ArrendatarioID),
    ActivoID        INT           NOT NULL CONSTRAINT FK_Con_Act REFERENCES dbo.Activos(ActivoID),
    TipoLeasing     NVARCHAR(12)  NOT NULL,
    FechaInicio     DATE          NOT NULL,
    PlazoMeses      SMALLINT      NOT NULL,
    ValorActivo     DECIMAL(14,2) NOT NULL,
    PrimaPorcentaje DECIMAL(5,2)  NOT NULL,
    MontoFinanciado DECIMAL(14,2) NOT NULL,
    TasaAnual       DECIMAL(5,2)  NOT NULL,
    ValorResidual   DECIMAL(14,2) NOT NULL,
    CuotaMensualSinIVA DECIMAL(12,2) NOT NULL,
    Estado          NVARCHAR(25)  NOT NULL,
    OpcionCompra    NVARCHAR(15)  NULL,
    SaldoCapitalPendiente DECIMAL(14,2) NOT NULL,
    DiasMora        SMALLINT      NOT NULL
);
GO
CREATE TABLE dbo.CuotasLeasing (
    CuotaID          BIGINT IDENTITY(1,1) CONSTRAINT PK_CuotasLeasing PRIMARY KEY,
    ContratoID       INT           NOT NULL CONSTRAINT FK_Cuo_Con REFERENCES dbo.ContratosLeasing(ContratoID),
    NumeroCuota      SMALLINT      NOT NULL,
    FechaVencimiento DATE          NOT NULL,
    Capital          DECIMAL(12,2) NOT NULL,
    Interes          DECIMAL(12,2) NOT NULL,
    IVA              DECIMAL(12,2) NOT NULL,
    Seguro           DECIMAL(12,2) NOT NULL,
    TotalCuota       DECIMAL(12,2) NOT NULL,
    FechaPago        DATE          NULL,
    MontoPagado      DECIMAL(12,2) NULL,
    Estado           NVARCHAR(12)  NOT NULL,
    DiasMora         SMALLINT      NOT NULL
);
GO
CREATE TABLE dbo.SegurosActivo (
    SeguroID      INT IDENTITY(1,1) CONSTRAINT PK_SegurosActivo PRIMARY KEY,
    ContratoID    INT           NOT NULL CONSTRAINT FK_Seg_Con REFERENCES dbo.ContratosLeasing(ContratoID),
    Aseguradora   NVARCHAR(60)  NOT NULL,
    NumeroPoliza  VARCHAR(20)   NOT NULL,
    Cobertura     NVARCHAR(40)  NOT NULL,
    PrimaAnual    DECIMAL(12,2) NOT NULL,
    VigenciaDesde DATE          NOT NULL,
    VigenciaHasta DATE          NOT NULL
);
GO

""")
        inserts(f, "Arrendatarios", ["ArrendatarioID","TipoPersona","NombreRazonSocial","Documento","GiroEconomico","Departamento","Municipio","Email","Telefono","IngresoAnual"], arr)
        inserts(f, "ProveedoresActivo", ["ProveedorID","Nombre","TipoProveedor","NIT"], proveedores)
        inserts(f, "Activos", ["ActivoID","TipoActivo","Marca","Modelo","Anio","NumeroSerieVIN","ValorCompra","ProveedorID","Condicion"], activos)
        inserts(f, "ContratosLeasing", ["ContratoID","NumeroContrato","ArrendatarioID","ActivoID","TipoLeasing","FechaInicio","PlazoMeses","ValorActivo","PrimaPorcentaje","MontoFinanciado","TasaAnual","ValorResidual","CuotaMensualSinIVA","Estado","OpcionCompra","SaldoCapitalPendiente","DiasMora"], contratos)
        inserts(f, "CuotasLeasing", ["CuotaID","ContratoID","NumeroCuota","FechaVencimiento","Capital","Interes","IVA","Seguro","TotalCuota","FechaPago","MontoPagado","Estado","DiasMora"], cuotas)
        inserts(f, "SegurosActivo", ["SeguroID","ContratoID","Aseguradora","NumeroPoliza","Cobertura","PrimaAnual","VigenciaDesde","VigenciaHasta"], seguros)
        f.write("""CREATE INDEX IX_Cuo_Contrato ON dbo.CuotasLeasing(ContratoID, NumeroCuota);
CREATE INDEX IX_Con_Arr ON dbo.ContratosLeasing(ArrendatarioID);
GO
CREATE VIEW dbo.vw_CarteraLeasing AS
SELECT c.NumeroContrato, a.TipoPersona, a.NombreRazonSocial, ac.TipoActivo, ac.Marca, ac.Modelo,
       c.TipoLeasing, c.MontoFinanciado, c.SaldoCapitalPendiente, c.Estado, c.DiasMora
FROM dbo.ContratosLeasing c
JOIN dbo.Arrendatarios a ON a.ArrendatarioID = c.ArrendatarioID
JOIN dbo.Activos ac ON ac.ActivoID = c.ActivoID;
GO
""")
        footer(f, db, tablas)
    STATS[db] = {"Arrendatarios": len(arr), "ProveedoresActivo": len(proveedores), "Activos": len(activos), "ContratosLeasing": len(contratos),
                 "CuotasLeasing": len(cuotas), "SegurosActivo": len(seguros)}

# ============================================================ 5. PRÉSTAMOS
def categoria_riesgo(d):
    return "A1" if d <= 7 else "A2" if d <= 30 else "B" if d <= 60 else "C1" if d <= 90 else "C2" if d <= 120 else "D1" if d <= 150 else "D2" if d <= 180 else "E"

def db_prestamos():
    rnd = random.Random(505)
    db = "BancaPrestamos"
    prods = [  # id, nombre, tipo, tmin, tmax, pmin, pmax, mmin, mmax, peso
        [1, "Préstamo Personal de Consumo", "Personal", 14.0, 24.0, 6, 84, 500, 25000, 26],
        [2, "Préstamo con Descuento por Planilla", "Personal", 10.0, 16.0, 12, 120, 1000, 40000, 18],
        [3, "Préstamo Hipotecario para Vivienda", "Hipotecario", 7.0, 11.0, 120, 300, 25000, 250000, 10],
        [4, "Vivienda de Interés Social", "Hipotecario", 6.0, 8.0, 120, 300, 15000, 60000, 5],
        [5, "Préstamo para Vehículo Nuevo", "Vehículo", 9.0, 13.0, 24, 84, 10000, 60000, 9],
        [6, "Préstamo para Vehículo Usado", "Vehículo", 11.0, 16.0, 12, 60, 5000, 30000, 7],
        [7, "Crédito PYME Capital de Trabajo", "PYME", 11.0, 18.0, 6, 36, 5000, 100000, 9],
        [8, "Crédito PYME Inversión", "PYME", 10.0, 15.0, 24, 120, 10000, 300000, 5],
        [9, "Préstamo Educativo", "Educativo", 8.0, 12.0, 12, 96, 2000, 30000, 4],
        [10, "Préstamo con Garantía de Depósito", "Garantizado", 6.0, 9.0, 6, 60, 1000, 50000, 7],
    ]
    destinos = {"Personal": ["Consolidación de deudas","Gastos médicos","Remodelación de vivienda","Viaje","Consumo general"],
                "Hipotecario": ["Compra de vivienda","Construcción de vivienda","Compra de terreno"],
                "Vehículo": ["Vehículo de uso personal","Vehículo de trabajo"],
                "PYME": ["Capital de trabajo","Compra de inventario","Compra de maquinaria","Ampliación de local"],
                "Educativo": ["Pregrado","Maestría","Diplomado en el exterior"],
                "Garantizado": ["Consumo general","Inversión personal"]}
    ejecutivos = [[i, f"{rnd.choice(NOM_M + NOM_F)} {rnd.choice(APE)}", rnd.choice(["Banca Personas","Banca PYME","Hipotecario"]), rnd.randint(1, 40)] for i in range(1, 61)]
    solicitudes, prestamos, cuotas, garantias, gestiones, pagos = [], [], [], [], [], []
    pid = 0
    for sid in range(1, 4501):
        cli = CLIENTES[rnd.randint(0, len(CLIENTES) - 1)]
        p = rnd.choices(prods, weights=[x[9] for x in prods])[0]
        fsol = max(cli[12], HOY - D(days=rnd.randint(1, 6 * 365)))
        plazo = rnd.choice([m for m in [6, 12, 18, 24, 36, 48, 60, 72, 84, 96, 120, 180, 240, 300] if p[5] <= m <= p[6]])
        monto = r2(round(min(p[8], max(p[7], rnd.lognormvariate(math.log(max(p[7] * 2, cli[10] * (30 if p[2] == "Hipotecario" else 6))), 0.5))) / 100) * 100)
        score = int(min(850, max(300, rnd.gauss(660, 85))))
        dti = r2(cuota_francesa(monto, (p[3] + p[4]) / 2, plazo) / cli[10] * 100)
        motivo = None
        if (HOY - fsol).days < 15 and rnd.random() < 0.5: est = "En análisis"
        elif score < 540: est, motivo = "Rechazada", "Score de buró insuficiente"
        elif dti > 55: est, motivo = "Rechazada", "Capacidad de pago insuficiente"
        elif rnd.random() < 0.05: est, motivo = "Rechazada", rnd.choice(["Documentación incompleta","Referencias negativas","Política de edad","Actividad económica no financiable"])
        elif rnd.random() < 0.03: est = "Desistida"
        else: est = "Aprobada"
        canal = rnd.choices(["Agencia","App móvil","Banca en línea","Ejecutivo de negocios","Feria de vivienda"], weights=[35, 25, 15, 20, 5])[0]
        eje = rnd.randint(1, 60)
        solicitudes.append([sid, cli[0], p[0], fsol, monto, plazo, rnd.choice(destinos[p[2]]), score, dti, est, motivo, canal, eje])
        if est != "Aprobada": continue
        pid += 1
        tasa = r2(p[3] + (p[4] - p[3]) * (850 - score) / 550)
        fdes = fsol + D(days=rnd.randint(2, 25 if p[2] != "Hipotecario" else 45))
        if fdes > HOY: fdes = HOY
        cuota = r2(cuota_francesa(monto, tasa, plazo))
        comport = rnd.choices(["Puntual","Tardío","Moroso","Castigo"], weights=[74, 17, 7, 2])[0]
        prepago = rnd.random() < 0.07
        transcurridas = months_between(fdes, HOY)
        saldo = monto
        dmora_actual = 0
        n_hasta = min(plazo, transcurridas + 1)
        k_prepago = rnd.randint(6, max(6, n_hasta)) if prepago and n_hasta > 12 else None
        cancelado = False
        vencidas_pend = 0
        r = tasa / 1200
        corte_moroso = rnd.choice([1, 2, 3, 4, 5, 8]) if comport == "Moroso" else (rnd.randint(7, 12) if comport == "Castigo" else 0)
        for k in range(1, n_hasta + 1):
            fv = add_months(fdes, k)
            interes = r2(saldo * r)
            capital = r2(min(saldo, cuota - interes)) if k < plazo else r2(saldo)
            fpago = mp = None
            dm = 0
            if fv <= HOY:
                if corte_moroso and k > transcurridas - corte_moroso:
                    est_c = "Vencida"; dm = (HOY - fv).days; vencidas_pend += 1
                    dmora_actual = max(dmora_actual, dm)
                else:
                    atraso = 0 if comport == "Puntual" else rnd.choice([0, 0, 1, 3, 6, 10, 18, 25])
                    fpago = min(fv + D(days=atraso), HOY)
                    dm = (fpago - fv).days
                    mp = r2(capital + interes + (r2((capital + interes) * 0.0006 * dm) if dm > 0 else 0))
                    est_c = "Pagada"
                    pagos.append([None, fpago, mp, capital, interes, r2(mp - capital - interes), rnd.choice(["Agencia","App móvil","Banca en línea","Descuento planilla" if p[0] == 2 else "Débito automático","Corresponsal"])])
                    pagos[-1][0] = pid
                    saldo = r2(saldo - capital)
            else:
                est_c = "Pendiente"
            cuotas.append([pid, k, fv, r2(capital + interes), capital, interes, r2(saldo) if est_c == "Pagada" else r2(saldo - capital), fpago, mp, est_c, dm])
            if k_prepago and k == k_prepago and est_c == "Pagada":
                pagos.append([pid, fpago, saldo, saldo, 0.0, 0.0, "Cancelación anticipada"])
                saldo = 0.0
                cancelado = True
                break
        if not cancelado and saldo <= 0.01 and n_hasta == plazo and vencidas_pend == 0: cancelado = True
        if cancelado: est_p, saldo = "Cancelado", 0.0
        elif comport == "Castigo" and dmora_actual > 360: est_p = "Castigado"
        elif dmora_actual > 90: est_p = "Vencido (cobro judicial)" if dmora_actual > 180 else "Vencido"
        elif dmora_actual > 0: est_p = "En mora"
        else: est_p = "Vigente"
        num = f"PR-{p[0]:02d}-{fdes.year}-{pid:06d}"
        prestamos.append([pid, num, sid, cli[0], p[0], fdes, monto, tasa, plazo, cuota, r2(saldo), est_p, dmora_actual, categoria_riesgo(dmora_actual), add_months(fdes, plazo), eje])
        # garantías
        tipo = p[2]
        if tipo == "Hipotecario" or (tipo == "PYME" and rnd.random() < 0.4):
            garantias.append([pid, "Hipotecaria", rnd.choice(["Casa de habitación","Apartamento","Terreno urbano","Local comercial"]) + " en " + cli[9], r2(monto / rnd.uniform(0.65, 0.85)), fdes - D(days=rnd.randint(10, 60)), f"Matrícula CNR {rnd.randint(10000000, 99999999)}-{rnd.randint(0, 99999):05d}"])
        elif tipo == "Vehículo" or (tipo == "PYME" and rnd.random() < 0.5):
            veh = rnd.choice(["Toyota Hilux","Nissan Frontier","Hyundai Tucson","Kia Sportage","Mazda CX-30","Isuzu D-Max","Maquinaria industrial"])
            garantias.append([pid, "Prendaria", veh, r2(monto / rnd.uniform(0.7, 0.9)), fdes - D(days=rnd.randint(1, 20)), f"Placa P{rnd.randint(100, 999)}-{rnd.randint(100, 999)}" if "Maquinaria" not in veh else f"Serie {rnd.randint(10**7, 10**8)}"])
        elif tipo == "Garantizado":
            garantias.append([pid, "Pignoración de depósito a plazo", "Certificado de depósito a plazo fijo", r2(monto / 0.9), fdes, f"DPF-{rnd.randint(10**6, 10**7)}"])
        elif rnd.random() < 0.35:
            garantias.append([pid, "Fiduciaria", f"Fiador: {rnd.choice(NOM_M + NOM_F)} {rnd.choice(APE)} {rnd.choice(APE)}", r2(monto), fdes, f"DUI {rnd.randint(1000000, 99999999):08d}-{rnd.randint(0, 9)}"])
        if rnd.random() < 0.8 and tipo in ("Hipotecario", "Personal", "Vehículo"):
            garantias.append([pid, "Seguro de deuda", "Póliza de vida saldo deudor", r2(monto), fdes, f"POL-VD-{rnd.randint(10**5, 10**6)}"])
        # gestiones de cobro
        if dmora_actual > 0 or comport == "Tardío":
            ng = min(12, max(1, dmora_actual // 15)) if dmora_actual else rnd.randint(1, 3)
            for g in range(ng):
                fg = rand_dt(rnd, max(fdes, HOY - D(days=max(dmora_actual, 60))), HOY)
                tg = rnd.choices(["Llamada telefónica","SMS","WhatsApp","Correo electrónico","Visita de campo","Carta de cobro","Traslado a jurídico"], weights=[35, 20, 15, 10, 10, 7, 3 if dmora_actual > 120 else 0])[0]
                res = rnd.choices(["Promesa de pago","No contesta","Número equivocado","Cliente sin capacidad de pago","Pago realizado","Solicita reestructuración","Mensaje dejado"], weights=[30, 25, 3, 8, 12, 7, 15])[0]
                fpp = (fg + D(days=rnd.randint(2, 10))).date() if res == "Promesa de pago" else None
                gestiones.append([pid, fg, tg, res, fpp, r2(cuota * rnd.choice([1, 1, 2])) if fpp else None, f"Gestor {rnd.randint(1, 25):02d}"])
    cuo_rows = [[i + 1] + c for i, c in enumerate(cuotas)]
    pagos.sort(key=lambda x: x[1])
    pago_rows = [[i + 1] + x for i, x in enumerate(pagos)]
    gar_rows = [[i + 1] + g for i, g in enumerate(garantias)]
    gestiones.sort(key=lambda g: g[1])
    ges_rows = [[i + 1] + g for i, g in enumerate(gestiones)]

    tablas = ["Clientes","EjecutivosNegocio","ProductosPrestamo","SolicitudesCredito","Prestamos","CuotasPrestamo","PagosPrestamo","Garantias","GestionesCobro"]
    with open(f"{OUT}/05_BancaPrestamos.sql", "w", encoding="utf-8-sig") as f:
        header(f, db, "Créditos: solicitudes, préstamos (personal, hipotecario, vehículo, PYME, educativo), amortización, pagos, garantías y cobranza", ", ".join(tablas))
        f.write(CLI_DDL)
        f.write("""CREATE TABLE dbo.EjecutivosNegocio (
    EjecutivoID  INT IDENTITY(1,1) CONSTRAINT PK_Ejecutivos PRIMARY KEY,
    Nombre       NVARCHAR(80) NOT NULL,
    Area         NVARCHAR(30) NOT NULL,
    AgenciaID    INT          NOT NULL
);
GO
CREATE TABLE dbo.ProductosPrestamo (
    ProductoID   INT IDENTITY(1,1) CONSTRAINT PK_ProductosPrestamo PRIMARY KEY,
    Nombre       NVARCHAR(60)  NOT NULL,
    TipoCredito  NVARCHAR(20)  NOT NULL,
    TasaMinima   DECIMAL(5,2)  NOT NULL,
    TasaMaxima   DECIMAL(5,2)  NOT NULL,
    PlazoMinimoMeses SMALLINT  NOT NULL,
    PlazoMaximoMeses SMALLINT  NOT NULL,
    MontoMinimo  DECIMAL(14,2) NOT NULL,
    MontoMaximo  DECIMAL(14,2) NOT NULL
);
GO
CREATE TABLE dbo.SolicitudesCredito (
    SolicitudID      INT IDENTITY(1,1) CONSTRAINT PK_Solicitudes PRIMARY KEY,
    ClienteID        INT           NOT NULL CONSTRAINT FK_Sol_Cliente REFERENCES dbo.Clientes(ClienteID),
    ProductoID       INT           NOT NULL CONSTRAINT FK_Sol_Prod REFERENCES dbo.ProductosPrestamo(ProductoID),
    FechaSolicitud   DATE          NOT NULL,
    MontoSolicitado  DECIMAL(14,2) NOT NULL,
    PlazoSolicitado  SMALLINT      NOT NULL,
    Destino          NVARCHAR(60)  NOT NULL,
    ScoreBuro        SMALLINT      NOT NULL,
    RelacionCuotaIngreso DECIMAL(7,2) NOT NULL,
    Estado           NVARCHAR(15)  NOT NULL,
    MotivoRechazo    NVARCHAR(60)  NULL,
    CanalOrigen      NVARCHAR(30)  NOT NULL,
    EjecutivoID      INT           NOT NULL CONSTRAINT FK_Sol_Eje REFERENCES dbo.EjecutivosNegocio(EjecutivoID)
);
GO
CREATE TABLE dbo.Prestamos (
    PrestamoID        INT IDENTITY(1,1) CONSTRAINT PK_Prestamos PRIMARY KEY,
    NumeroPrestamo    VARCHAR(25)   NOT NULL CONSTRAINT UQ_Prestamo UNIQUE,
    SolicitudID       INT           NOT NULL CONSTRAINT FK_Pre_Sol REFERENCES dbo.SolicitudesCredito(SolicitudID),
    ClienteID         INT           NOT NULL CONSTRAINT FK_Pre_Cliente REFERENCES dbo.Clientes(ClienteID),
    ProductoID        INT           NOT NULL CONSTRAINT FK_Pre_Prod REFERENCES dbo.ProductosPrestamo(ProductoID),
    FechaDesembolso   DATE          NOT NULL,
    MontoDesembolsado DECIMAL(14,2) NOT NULL,
    TasaAnual         DECIMAL(5,2)  NOT NULL,
    PlazoMeses        SMALLINT      NOT NULL,
    CuotaMensual      DECIMAL(12,2) NOT NULL,
    SaldoCapital      DECIMAL(14,2) NOT NULL,
    Estado            NVARCHAR(30)  NOT NULL,
    DiasMora          SMALLINT      NOT NULL,
    CategoriaRiesgo   VARCHAR(2)    NOT NULL,   -- A1, A2, B, C1, C2, D1, D2, E (NCB-022)
    FechaVencimientoFinal DATE      NOT NULL,
    EjecutivoID       INT           NOT NULL CONSTRAINT FK_Pre_Eje REFERENCES dbo.EjecutivosNegocio(EjecutivoID)
);
GO
CREATE TABLE dbo.CuotasPrestamo (
    CuotaID          BIGINT IDENTITY(1,1) CONSTRAINT PK_CuotasPrestamo PRIMARY KEY,
    PrestamoID       INT           NOT NULL CONSTRAINT FK_CuoP_Pre REFERENCES dbo.Prestamos(PrestamoID),
    NumeroCuota      SMALLINT      NOT NULL,
    FechaVencimiento DATE          NOT NULL,
    CuotaProgramada  DECIMAL(12,2) NOT NULL,
    Capital          DECIMAL(12,2) NOT NULL,
    Interes          DECIMAL(12,2) NOT NULL,
    SaldoDespues     DECIMAL(14,2) NOT NULL,
    FechaPago        DATE          NULL,
    MontoPagado      DECIMAL(12,2) NULL,
    Estado           NVARCHAR(12)  NOT NULL,
    DiasMora         SMALLINT      NOT NULL
);
GO
CREATE TABLE dbo.PagosPrestamo (
    PagoID          BIGINT IDENTITY(1,1) CONSTRAINT PK_PagosPrestamo PRIMARY KEY,
    PrestamoID      INT           NOT NULL CONSTRAINT FK_PagP_Pre REFERENCES dbo.Prestamos(PrestamoID),
    FechaPago       DATE          NOT NULL,
    MontoTotal      DECIMAL(14,2) NOT NULL,
    AbonoCapital    DECIMAL(14,2) NOT NULL,
    AbonoInteres    DECIMAL(12,2) NOT NULL,
    InteresMoratorio DECIMAL(12,2) NOT NULL,
    Canal           NVARCHAR(30)  NOT NULL
);
GO
CREATE TABLE dbo.Garantias (
    GarantiaID     INT IDENTITY(1,1) CONSTRAINT PK_Garantias PRIMARY KEY,
    PrestamoID     INT           NOT NULL CONSTRAINT FK_Gar_Pre REFERENCES dbo.Prestamos(PrestamoID),
    TipoGarantia   NVARCHAR(40)  NOT NULL,
    Descripcion    NVARCHAR(120) NOT NULL,
    ValorAvaluo    DECIMAL(14,2) NOT NULL,
    FechaAvaluo    DATE          NOT NULL,
    Referencia     NVARCHAR(60)  NOT NULL
);
GO
CREATE TABLE dbo.GestionesCobro (
    GestionID      INT IDENTITY(1,1) CONSTRAINT PK_GestionesCobro PRIMARY KEY,
    PrestamoID     INT           NOT NULL CONSTRAINT FK_Ges_Pre REFERENCES dbo.Prestamos(PrestamoID),
    FechaHora      DATETIME2(0)  NOT NULL,
    TipoGestion    NVARCHAR(30)  NOT NULL,
    Resultado      NVARCHAR(40)  NOT NULL,
    FechaPromesaPago DATE        NULL,
    MontoPromesa   DECIMAL(12,2) NULL,
    Gestor         NVARCHAR(30)  NOT NULL
);
GO

""")
        inserts(f, "Clientes", CLI_COLS, CLIENTES)
        inserts(f, "EjecutivosNegocio", ["EjecutivoID","Nombre","Area","AgenciaID"], ejecutivos)
        inserts(f, "ProductosPrestamo", ["ProductoID","Nombre","TipoCredito","TasaMinima","TasaMaxima","PlazoMinimoMeses","PlazoMaximoMeses","MontoMinimo","MontoMaximo"],
                [[p[0], p[1], p[2], p[3], p[4], p[5], p[6], float(p[7]), float(p[8])] for p in prods])
        inserts(f, "SolicitudesCredito", ["SolicitudID","ClienteID","ProductoID","FechaSolicitud","MontoSolicitado","PlazoSolicitado","Destino","ScoreBuro","RelacionCuotaIngreso","Estado","MotivoRechazo","CanalOrigen","EjecutivoID"], solicitudes)
        inserts(f, "Prestamos", ["PrestamoID","NumeroPrestamo","SolicitudID","ClienteID","ProductoID","FechaDesembolso","MontoDesembolsado","TasaAnual","PlazoMeses","CuotaMensual","SaldoCapital","Estado","DiasMora","CategoriaRiesgo","FechaVencimientoFinal","EjecutivoID"], prestamos)
        inserts(f, "CuotasPrestamo", ["CuotaID","PrestamoID","NumeroCuota","FechaVencimiento","CuotaProgramada","Capital","Interes","SaldoDespues","FechaPago","MontoPagado","Estado","DiasMora"], cuo_rows)
        inserts(f, "PagosPrestamo", ["PagoID","PrestamoID","FechaPago","MontoTotal","AbonoCapital","AbonoInteres","InteresMoratorio","Canal"], pago_rows)
        inserts(f, "Garantias", ["GarantiaID","PrestamoID","TipoGarantia","Descripcion","ValorAvaluo","FechaAvaluo","Referencia"], gar_rows)
        inserts(f, "GestionesCobro", ["GestionID","PrestamoID","FechaHora","TipoGestion","Resultado","FechaPromesaPago","MontoPromesa","Gestor"], ges_rows)
        f.write("""CREATE INDEX IX_Pre_Cliente ON dbo.Prestamos(ClienteID);
CREATE INDEX IX_CuoP_Pre ON dbo.CuotasPrestamo(PrestamoID, NumeroCuota);
CREATE INDEX IX_PagP_Pre ON dbo.PagosPrestamo(PrestamoID, FechaPago);
GO
CREATE VIEW dbo.vw_CarteraPorCategoria AS
SELECT pp.TipoCredito, p.CategoriaRiesgo, COUNT(*) AS Prestamos, SUM(p.SaldoCapital) AS SaldoCapital
FROM dbo.Prestamos p
JOIN dbo.ProductosPrestamo pp ON pp.ProductoID = p.ProductoID
WHERE p.Estado <> N'Cancelado'
GROUP BY pp.TipoCredito, p.CategoriaRiesgo;
GO
""")
        footer(f, db, tablas)
    STATS[db] = {"Clientes": len(CLIENTES), "EjecutivosNegocio": 60, "ProductosPrestamo": len(prods), "SolicitudesCredito": len(solicitudes), "Prestamos": len(prestamos),
                 "CuotasPrestamo": len(cuo_rows), "PagosPrestamo": len(pago_rows), "Garantias": len(gar_rows), "GestionesCobro": len(ges_rows)}

if __name__ == "__main__":
    db_tarjetas_credito(); db_debito(); db_tokenizacion(); db_leasing(); db_prestamos()
    import json
    print(json.dumps(STATS, indent=1, ensure_ascii=False))
    for fn in sorted(os.listdir(OUT)):
        print(fn, round(os.path.getsize(f"{OUT}/{fn}") / 1e6, 1), "MB")
